using UnityEngine;

/// <summary>
/// КОНТРОЛЛЕР АТМОСФЕРНЫХ ЗВУКОВ
/// Управляет всеми звуками вступительной сцены:
/// - Гудок поезда
/// - Вода в трубах
/// - Батарея отопления
/// - Ветер
/// - Собаки
/// - Радио за стеной
/// - Дождь
/// 
/// Для каждого звука нужно назначить AudioClip в Inspector Unity.
/// Звуки нужно найти/записать отдельно (см. список ниже).
/// </summary>
public class AtmosphericAudio : MonoBehaviour
{
    public enum SoundType
    {
        TrainHorn,       // Гудок товарного поезда
        WaterPipes,      // Вода в старых трубах
        HeatBattery,     // Скрип батареи отопления
        Wind,            // Ветер в щелях
        Dogs,            // Лай собак
        Radio,           // Радио за стеной
        Rain,            // Дождь
        Footsteps,       // Далёкие шаги
        FloorCreak,      // Скрип пола
        TrafficAmbient,  // Городской шум (фоновый)
    }

    [Header("=== ЗВУКИ ВСТУПЛЕНИЯ ===")]
    [Header("Назначьте аудиофайлы в Inspector")]
    [SerializeField] private AudioClip trainHorn;
    [SerializeField] private AudioClip waterPipes;
    [SerializeField] private AudioClip heatBattery;
    [SerializeField] private AudioClip wind;
    [SerializeField] private AudioClip dogs;
    [SerializeField] private AudioClip radio;
    [SerializeField] private AudioClip rain;
    [SerializeField] private AudioClip footsteps;
    [SerializeField] private AudioClip floorCreak;
    [SerializeField] private AudioClip trafficAmbient;

    [Header("=== ФОНОВЫЙ ЗВУК ===")]
    [SerializeField] private AudioSource ambientSource;   // Для непрерывных звуков (дождь, трафик)
    [SerializeField] private AudioSource effectSource;    // Для разовых звуков

    void Start()
    {
        // Запускаем фоновый городской шум сразу
        if (ambientSource != null && trafficAmbient != null)
        {
            ambientSource.clip = trafficAmbient;
            ambientSource.loop = true;
            ambientSource.volume = 0.1f; // Очень тихо, фон
            ambientSource.Play();
        }
    }

    /// <summary>
    /// Воспроизвести атмосферный звук
    /// Вызывается из CinematicSequencer по расписанию
    /// </summary>
    public void PlaySound(SoundType soundType)
    {
        AudioClip clip = GetClip(soundType);

        if (clip == null)
        {
            Debug.LogWarning($"[Звук] Аудиофайл не назначен: {soundType}");
            return;
        }

        if (effectSource != null)
            effectSource.PlayOneShot(clip);

        Debug.Log($"[Звук] Воспроизводится: {soundType}");
    }

    /// <summary>
    /// Запустить фоновый звук в петле (дождь, ветер)
    /// </summary>
    public void StartAmbientLoop(SoundType soundType, float volume = 0.5f)
    {
        AudioClip clip = GetClip(soundType);
        if (clip == null || ambientSource == null) return;

        ambientSource.clip = clip;
        ambientSource.volume = volume;
        ambientSource.loop = true;
        ambientSource.Play();
    }

    /// <summary>
    /// Плавно остановить фоновый звук
    /// </summary>
    public void StopAmbientLoop()
    {
        if (ambientSource != null)
            ambientSource.Stop();
    }

    AudioClip GetClip(SoundType soundType)
    {
        switch (soundType)
        {
            case SoundType.TrainHorn:      return trainHorn;
            case SoundType.WaterPipes:     return waterPipes;
            case SoundType.HeatBattery:    return heatBattery;
            case SoundType.Wind:           return wind;
            case SoundType.Dogs:           return dogs;
            case SoundType.Radio:          return radio;
            case SoundType.Rain:           return rain;
            case SoundType.Footsteps:      return footsteps;
            case SoundType.FloorCreak:     return floorCreak;
            case SoundType.TrafficAmbient: return trafficAmbient;
            default: return null;
        }
    }
}
