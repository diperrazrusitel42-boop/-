using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// ГЛАВНЫЙ РЕЖИССЁР ВСТУПИТЕЛЬНОЙ СЦЕНЫ
/// Этот скрипт управляет всей последовательностью до передачи управления игроку.
/// Вешается на пустой объект CinematicDirector в сцене.
/// 
/// Последовательность:
/// 1. Чёрный экран + звуки (Сцена 1)
/// 2. Потолок + монолог (Сцена 2)  
/// 3. Подоконник + предметы (Сцена 3)
/// 4. Вставание + передача управления
/// </summary>
public class CinematicSequencer : MonoBehaviour
{
    public static CinematicSequencer Instance;

    [Header("=== КОМПОНЕНТЫ ===")]
    [SerializeField] private CinematicCamera cinematicCamera;     // Кинематографическая камера
    [SerializeField] private BlackScreenController blackScreen;    // Контроллер чёрного экрана
    [SerializeField] private MonologueController monologue;       // Контроллер монологов
    [SerializeField] private AtmosphericAudio atmosphericAudio;   // Атмосферные звуки
    [SerializeField] private PlayerController playerController;   // Контроллер игрока

    [Header("=== НАСТРОЙКИ ===")]
    [SerializeField] private bool skipIntro = false;  // Пропустить вступление (для тестов)

    // Флаг завершения вступления
    private bool introComplete = false;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        if (skipIntro)
        {
            StartGame();
            return;
        }

        // Отключаем управление игрока на время вступления
        if (playerController != null)
            playerController.SetMovementEnabled(false);

        // Запускаем вступительную последовательность
        StartCoroutine(PlayIntroSequence());
    }

    // ==========================================
    // ГЛАВНАЯ ПОСЛЕДОВАТЕЛЬНОСТЬ
    // ==========================================

    IEnumerator PlayIntroSequence()
    {
        // СЦЕНА 1: Чёрный экран и звуки
        yield return StartCoroutine(Scene1_BlackScreen());

        // СЦЕНА 2: Потолок
        yield return StartCoroutine(Scene2_Ceiling());

        // СЦЕНА 3: Подоконник
        yield return StartCoroutine(Scene3_Windowsill());

        // ФИНАЛ: Передача управления
        yield return StartCoroutine(TransitionToPlayer());
    }

    // ==========================================
    // СЦЕНА 1: ЧЁРНЫЙ ЭКРАН (0:00 - 2:00)
    // ==========================================

    IEnumerator Scene1_BlackScreen()
    {
        Debug.Log("[СЦЕНА 1] Чёрный экран - начало");

        // Экран полностью чёрный
        blackScreen.SetAlpha(1f);

        // Запускаем атмосферные звуки поочерёдно
        yield return new WaitForSeconds(1f);

        // Гудок поезда
        atmosphericAudio.PlaySound(AtmosphericAudio.SoundType.TrainHorn);
        yield return new WaitForSeconds(16f);

        // Вода в трубах
        atmosphericAudio.PlaySound(AtmosphericAudio.SoundType.WaterPipes);
        yield return new WaitForSeconds(4f);

        // Батарея
        atmosphericAudio.PlaySound(AtmosphericAudio.SoundType.HeatBattery);
        yield return new WaitForSeconds(5f);

        // Ветер
        atmosphericAudio.PlaySound(AtmosphericAudio.SoundType.Wind);
        yield return new WaitForSeconds(5f);

        // 10 секунд тишины
        yield return new WaitForSeconds(10f);

        // Собаки
        atmosphericAudio.PlaySound(AtmosphericAudio.SoundType.Dogs);
        yield return new WaitForSeconds(8f);

        // Монолог в темноте
        monologue.PlayMonologue(MonologueController.MonologueID.Scene1_City);
        yield return new WaitForSeconds(8f);

        Debug.Log("[СЦЕНА 1] Завершена");
    }

    // ==========================================
    // СЦЕНА 2: ПОТОЛОК (2:00 - 10:00)
    // ==========================================

    IEnumerator Scene2_Ceiling()
    {
        Debug.Log("[СЦЕНА 2] Потолок - начало");

        // Медленный fadeIn из темноты
        yield return StartCoroutine(blackScreen.FadeOut(3f));

        // Камера смотрит на потолок
        cinematicCamera.SetTarget(CinematicCamera.CameraTarget.Ceiling);

        yield return new WaitForSeconds(2f);

        // Монолог про потолок и трещины
        monologue.PlayMonologue(MonologueController.MonologueID.Scene2_Ceiling);
        yield return new WaitForSeconds(6f);

        // Камера медленно панорамирует вправо (к стене с обоями)
        yield return StartCoroutine(cinematicCamera.PanTo(
            CinematicCamera.CameraTarget.WallWithWallpaper, 4f));

        // Монолог про империи и трещины
        monologue.PlayMonologue(MonologueController.MonologueID.Scene2_Empires);
        yield return new WaitForSeconds(8f);

        // Камера панорамирует к окну
        yield return StartCoroutine(cinematicCamera.PanTo(
            CinematicCamera.CameraTarget.Window, 4f));

        // Монолог про пыль
        monologue.PlayMonologue(MonologueController.MonologueID.Scene2_Dust);
        yield return new WaitForSeconds(6f);

        Debug.Log("[СЦЕНА 2] Завершена");
    }

    // ==========================================
    // СЦЕНА 3: ПОДОКОННИК (10:00 - 22:00)
    // ==========================================

    IEnumerator Scene3_Windowsill()
    {
        Debug.Log("[СЦЕНА 3] Подоконник - начало");

        // Камера опускается на подоконник
        yield return StartCoroutine(cinematicCamera.PanTo(
            CinematicCamera.CameraTarget.Windowsill, 3f));

        // Осмотр каждого предмета на подоконнике
        // Газеты
        yield return StartCoroutine(cinematicCamera.FocusOnItem("Newspaper"));
        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_Newspaper);
        yield return new WaitForSeconds(8f);

        // Кружка
        yield return StartCoroutine(cinematicCamera.FocusOnItem("Mug"));
        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_Mug);
        yield return new WaitForSeconds(6f);

        // Окурок
        yield return StartCoroutine(cinematicCamera.FocusOnItem("Cigarette"));
        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_Cigarette);
        yield return new WaitForSeconds(5f);

        // Счёт за электричество
        yield return StartCoroutine(cinematicCamera.FocusOnItem("ElectricBill"));
        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_ElectricBill);
        yield return new WaitForSeconds(6f);

        // Деньги (с флэшбеком)
        yield return StartCoroutine(cinematicCamera.FocusOnItem("Money"));
        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_Money);

        // Запускаем флэшбек (рынок, мужик с машиной)
        yield return StartCoroutine(PlayFlashback_Market());

        yield return new WaitForSeconds(6f);

        Debug.Log("[СЦЕНА 3] Завершена");
    }

    // ==========================================
    // ФЛЭШБЕК: РЫНОК
    // ==========================================

    IEnumerator PlayFlashback_Market()
    {
        Debug.Log("[ФЛЭШБЕК] Рынок - начало");

        // Затемнение
        yield return StartCoroutine(blackScreen.FadeIn(0.5f));
        yield return new WaitForSeconds(0.3f);

        // Переключаем на флэшбек камеру/сцену
        cinematicCamera.SetFlashbackMode(true);
        yield return new WaitForSeconds(0.3f);

        // Появляется флэшбек
        yield return StartCoroutine(blackScreen.FadeOut(1f));

        // Монолог во время флэшбека
        monologue.PlayMonologue(MonologueController.MonologueID.Flashback_Market);
        yield return new WaitForSeconds(8f);

        // Возврат к подоконнику
        yield return StartCoroutine(blackScreen.FadeIn(0.5f));
        cinematicCamera.SetFlashbackMode(false);
        yield return StartCoroutine(blackScreen.FadeOut(1f));

        monologue.PlayMonologue(MonologueController.MonologueID.Scene3_MoneyAfterFlashback);
        yield return new WaitForSeconds(5f);

        Debug.Log("[ФЛЭШБЕК] Рынок - завершён");
    }

    // ==========================================
    // ПЕРЕХОД К ИГРОКУ
    // ==========================================

    IEnumerator TransitionToPlayer()
    {
        Debug.Log("[ПЕРЕХОД] Передача управления игроку");

        // Герой встаёт с кровати
        yield return StartCoroutine(cinematicCamera.PanTo(
            CinematicCamera.CameraTarget.StandUp, 2f));

        yield return new WaitForSeconds(1f);

        // Финальное затемнение
        yield return StartCoroutine(blackScreen.FadeIn(1f));

        // Небольшая пауза
        yield return new WaitForSeconds(0.5f);

        // Включаем игрока
        StartGame();

        // Проявляем картинку
        yield return StartCoroutine(blackScreen.FadeOut(2f));
    }

    // ==========================================
    // СТАРТ ИГРЫ
    // ==========================================

    void StartGame()
    {
        introComplete = true;

        // Включаем управление
        if (playerController != null)
            playerController.SetMovementEnabled(true);

        // Переключаем на камеру игрока
        if (cinematicCamera != null)
            cinematicCamera.gameObject.SetActive(false);

        Debug.Log("[ИГРА] Управление передано игроку!");
    }
}
