using UnityEngine;
using System.Collections;

/// <summary>
/// СОБЫТИЕ С ТЕНЬЮ В ПОДЪЕЗДЕ (Сцена 7B)
/// 
/// Когда игрок выходит из квартиры соседа — внизу мелькает тень.
/// Система обрабатывает:
/// - Триггер появления тени
/// - Возможность выстрела (если есть револьвер и патроны)
/// - Последствия (цепочка, окурок в луже)
/// </summary>
public class ShadowEvent : MonoBehaviour
{
    [Header("Объекты сцены")]
    [SerializeField] private GameObject shadowObject;     // Силуэт убегающего
    [SerializeField] private Transform shadowExitPoint;  // Точка куда убегает
    [SerializeField] private GameObject chainOnFloor;    // Цепочка с распятием
    [SerializeField] private GameObject cigaretteInPuddle; // Окурок в луже

    [Header("Звуки")]
    [SerializeField] private AudioClip doorSlam;         // Хлопок двери
    [SerializeField] private AudioClip gunshot;          // Выстрел
    [SerializeField] private AudioClip carEngine;        // Двигатель "Заставы"

    [Header("Монологи")]
    [TextArea(2, 6)]
    [SerializeField] private string monologue_SeeShadow =
        "Я только вышел, как внизу мелькнула тень. " +
        "Кто-то выскочил так быстро, что дверь не успела закрыться бесшумно — " +
        "она грохнула, и эхо покатилось вверх по лестнице.\n\n" +
        "Я замер. Сердце заколотилось где-то в горле.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_ThinkAboutShadow =
        "Кто это был? Свидетель? Или тот, кто вернулся за забытой уликой? " +
        "А может, просто сосед, которому приспичило вынести мусор? " +
        "Но мусор не убегают.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Shot =
        "Рука сама потянулась к карману. Револьвер — тяжёлый, холодный. " +
        "Я вскинул руку. Прицелился. Выстрел.\n\n" +
        "Я попал. Он дёрнулся, но не упал. Побежал дальше. Только быстрее.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_NoShot =
        "Я не стал стрелять. Просто смотрел, как тень исчезает за дверью. " +
        "Потом завёлся двигатель — старый, дымный, похоже, «Застава» — и уехал.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Chain =
        "На бетонном полу, в пыли, лежала цепочка. " +
        "Тонкая, серебряная, с кулоном — распятие. " +
        "Я поднял её. Металл был тёплым.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_AfterEvent =
        "Я спустился вниз. Дверь подъезда была прикрыта, но не заперта. " +
        "На улице моросил дождь. Следы на грязи вели к проезду между домами. " +
        "И окурок в луже — дорогой, с фильтром. Такие же, как в пачке старика.";

    private bool eventTriggered = false;
    private AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();

        // Скрываем предметы события
        if (chainOnFloor != null) chainOnFloor.SetActive(false);
        if (cigaretteInPuddle != null) cigaretteInPuddle.SetActive(false);
        if (shadowObject != null) shadowObject.SetActive(false);
    }

    /// <summary>
    /// Триггер вызывается когда игрок выходит из квартиры соседа
    /// Повесьте коллайдер-триггер на выходе из квартиры
    /// </summary>
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (eventTriggered) return;

        eventTriggered = true;
        StartCoroutine(PlayShadowEvent());
    }

    IEnumerator PlayShadowEvent()
    {
        // Показываем тень
        if (shadowObject != null)
        {
            shadowObject.SetActive(true);
            // Анимация убегания (аниматор должен быть настроен)
            Animator anim = shadowObject.GetComponent<Animator>();
            if (anim != null) anim.SetTrigger("Run");
        }

        // Звук хлопка двери
        if (doorSlam != null && audioSource != null)
            audioSource.PlayOneShot(doorSlam);

        // Первый монолог
        UIManager.Instance?.ShowMonologue(monologue_SeeShadow);
        yield return new WaitForSeconds(5f);

        // Второй монолог — размышления
        UIManager.Instance?.ShowMonologue(monologue_ThinkAboutShadow);
        yield return new WaitForSeconds(3f);

        // Остановить движение игрока и дать выбор
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);
        yield return new WaitForSeconds(1f);

        // Показываем выбор: стрелять или нет
        ShowShootChoice();
    }

    void ShowShootChoice()
    {
        // Проверяем есть ли оружие
        bool hasRevolver = InventoryManager.Instance?.HasItem("Револьвер") ?? false;
        bool hasBullets = InventoryManager.Instance?.HasItem("Патроны 7.62 мм") ?? false;
        bool canShoot = hasRevolver && hasBullets;

        if (canShoot)
        {
            // Показываем UI с выбором
            ChoiceUIManager.Instance?.ShowChoice(
                "Тень исчезает за дверью...",
                new ChoiceOption("Выстрелить", OnChoiceShoot),
                new ChoiceOption("Не стрелять", OnChoiceNoShoot)
            );
        }
        else
        {
            // Нет оружия — только смотрит
            StartCoroutine(NoShootSequence());
        }
    }

    void OnChoiceShoot()
    {
        StartCoroutine(ShootSequence());
    }

    void OnChoiceNoShoot()
    {
        StartCoroutine(NoShootSequence());
    }

    IEnumerator ShootSequence()
    {
        // Звук выстрела
        if (gunshot != null && audioSource != null)
            audioSource.PlayOneShot(gunshot);

        UIManager.Instance?.ShowMonologue(monologue_Shot);
        yield return new WaitForSeconds(4f);

        // Появляется цепочка
        if (chainOnFloor != null)
        {
            chainOnFloor.SetActive(true);
            UIManager.Instance?.ShowMonologue(monologue_Chain);
        }

        yield return new WaitForSeconds(3f);
        FinishEvent();
    }

    IEnumerator NoShootSequence()
    {
        // Звук уезжающей машины
        yield return new WaitForSeconds(2f);
        if (carEngine != null && audioSource != null)
            audioSource.PlayOneShot(carEngine);

        UIManager.Instance?.ShowMonologue(monologue_NoShot);
        yield return new WaitForSeconds(4f);

        FinishEvent();
    }

    void FinishEvent()
    {
        // Появляется окурок в луже
        if (cigaretteInPuddle != null)
            cigaretteInPuddle.SetActive(true);

        UIManager.Instance?.ShowMonologue(monologue_AfterEvent);

        // Возвращаем управление
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);

        // Убираем тень
        if (shadowObject != null)
            shadowObject.SetActive(false);
    }
}
