using UnityEngine;

/// <summary>
/// ДАННЫЕ ВСЕХ ПРЕДМЕТОВ КОМНАТЫ ГЕРОЯ
/// Здесь хранятся все тексты для предметов в комнате.
/// Это справочный файл — тексты копируются в Inspector каждого предмета.
///
/// КАК ИСПОЛЬЗОВАТЬ:
/// 1. Создайте 3D-объект в Unity (куб, сфера — пока без модели)
/// 2. Добавьте компонент InteractableObject
/// 3. Скопируйте соответствующий текст из этого файла в поля Inspector
///
/// Этот скрипт НЕ вешается на объекты — он только для справки и быстрого доступа.
/// </summary>
public static class HeroRoomData
{
    // ============================================================
    // ТУМБОЧКА У КРОВАТИ
    // ============================================================

    public static readonly string DogTag_Name = "Армейский жетон";
    public static readonly string DogTag_Description =
        "Алюминиевый, потёртый, с выбитым номером. На тонком шнурке, почерневшем от времени.";
    public static readonly string DogTag_Monologue =
        "Если меня убьют, по нему опознают. Если найдут, конечно.";

    // ---

    public static readonly string MilitaryBook_Name = "Военная книжка";
    public static readonly string MilitaryBook_Description =
        "Красно-коричневая обложка, герб СФРЮ. Потрёпанная, засаленная пальцами.";
    public static readonly string MilitaryBook_Content =
        "ВОЕННАЯ КНИЖКА\n\n" +
        "Фамилия: ___________\n" +
        "Воинское звание: Рядовой\n\n" +
        "Службу проходил в мотострелковых войсках.\n" +
        "Участвовал в учениях:\n" +
        "— Маньяча (1989)\n" +
        "— Косово (1990)\n" +
        "— Словения (1991)\n\n" +
        "Награждён знаком «Отличник стрельбы».\n\n" +
        "Выбыл в запас в звании рядового.\n" +
        "Дата: август 1991 г.";
    public static readonly string MilitaryBook_Monologue =
        "Красно-коричневая обложка, герб СФРЮ. Потрёпанная, засаленная пальцами. " +
        "Там записано всё — где был, что делал, кем считался. " +
        "Выбыл в запас. Как будто я куда-то прибыл, а теперь выбываю. " +
        "Куда выбываю? В эту жизнь?";

    // ---

    public static readonly string ArmyPhoto_Name = "Фотография. Армия, 1989";
    public static readonly string ArmyPhoto_Description =
        "Групповой снимок. Солдаты в белых маскхалатах на фоне заснеженных гор. " +
        "Улыбаются, некоторые показывают пальцами в камеру.";
    public static readonly string ArmyPhoto_Monologue =
        "Это учения в Боснии, восемьдесят девятый. Мороз был под тридцать, а мы ползли по снегу. " +
        "Командир кричал: «Родина в опасности!» Мы смеялись. Теперь не до смеха.";

    // ---

    public static readonly string Diploma_Name = "Диплом слесаря-ремонтника";
    public static readonly string Diploma_Description =
        "В дешёвой деревянной рамке, под стеклом. Свежий, выдан год назад.";
    public static readonly string Diploma_Content =
        "СВИДЕТЕЛЬСТВО О ЗАКОНЧЕННОЙ ШКОЛЕ\n\n" +
        "Индустриально-ремесленная школа\n" +
        "Направление: слесарь-сварщик\n\n" +
        "Настоящим удостоверяется, что ___________ успешно\n" +
        "закончил курс обучения и имеет право работать\n" +
        "по специальности слесарь-ремонтник III разряда.\n\n" +
        "Дата выдачи: сентябрь 1990 г.";
    public static readonly string Diploma_Monologue =
        "Слесарь-ремонтник, третий разряд. Хорошая профессия. Земная. " +
        "Токарный станок не спросит, кто ты по национальности, за кого голосовал. " +
        "Ему всё равно. Лишь бы руки были прямые.";

    // ---

    public static readonly string HuntingMagazine_Name = "«Ловачки весник», 1988";
    public static readonly string HuntingMagazine_Description =
        "Охотничий журнал. Обложка потрёпана, страницы зачитаны до дыр. " +
        "На обложке — охотник с убитым оленем.";
    public static readonly string HuntingMagazine_Monologue =
        "Стрельбу в армии любил. Инструктор хвалил. Говорил — глаз алмаз, спокойные руки. " +
        "Хороший снайпер получился бы. Если бы война началась. " +
        "А она, кажется, начинается.";

    // ---

    public static readonly string Cartridge_Name = "Патрон 12 калибра";
    public static readonly string Cartridge_Description =
        "Латунная гильза, потёртая, использованная. Лежит отдельно от остального.";
    public static readonly string Cartridge_Monologue =
        "С первого моего охотничьего сезона. Дядя Милан брал меня на кабана. " +
        "Никого не убили, просто бродили по лесу, пили чай из термоса, слушали тишину. " +
        "Дядя потом уехал в Канаду. Говорит, там тишина лучше.";

    // ---

    public static readonly string BrokenWatch_Name = "Часы «Победа»";
    public static readonly string BrokenWatch_Description =
        "Советские, старые. Не идут — стрелки застыли на половине седьмого.";
    public static readonly string BrokenWatch_Monologue =
        "Отцовские. Он носил их до самой смерти. " +
        "Я починить хотел, да всё руки не доходят. " +
        "Теперь уже не до них.";

    // ============================================================
    // КНИЖНАЯ ПОЛКА
    // ============================================================

    public static readonly string Book_Andric_Name = "Иво Андрич. «Мост на Дрине»";
    public static readonly string Book_Andric_Description =
        "Собрание сочинений Андрича. Книга потрёпана — читали много раз.";
    public static readonly string Book_Andric_Monologue =
        "Моя любимая. Там про мост, который стоит века, а люди вокруг меняются. " +
        "Наш мост тоже стоит. Интересно, сколько ещё простоит?";

    public static readonly string Book_Selimovic_Name = "Меша Селимович. «Дервиш и смерть»";
    public static readonly string Book_Selimovic_Description =
        "Тяжёлая книга, не для слабых. Про то, как человека ломает система.";
    public static readonly string Book_Selimovic_Monologue =
        "Говорят, переиздали. Актуально, да.";

    public static readonly string Book_Manual_Name = "Справочник слесаря-ремонтника";
    public static readonly string Book_Manual_Description =
        "Три издания на полке. Самая полезная книга в доме.";
    public static readonly string Book_Manual_Monologue =
        "Это — настоящее. Это не обманывает. " +
        "Написано как есть: вот деталь, вот размер, вот как чинить.";

    // ============================================================
    // ФОТОГРАФИИ НА КОВРЕ
    // ============================================================

    public static readonly string Photo_Parents_Name = "Свадебная фотография. 1950-е";
    public static readonly string Photo_Parents_Description =
        "Чёрно-белая. Молодая пара. Невеста в белом, жених в костюме. Улыбаются.";
    public static readonly string Photo_Parents_Monologue =
        "Это родители. Мама говорила, они поженились через неделю после знакомства. " +
        "И прожили вместе сорок лет. " +
        "Теперь её нет, и его нет. А фотография висит.";

    public static readonly string Photo_Mom_Name = "Мама. Последняя фотография";
    public static readonly string Photo_Mom_Description =
        "Цветная. Женщина средних лет, в платке, стоит у дома. Серьёзная.";
    public static readonly string Photo_Mom_Monologue =
        "Мама. За год до смерти. Уже болела, но не показывала. " +
        "Всё улыбалась. «Всё будет хорошо», — говорила. " +
        "Не будет.";

    public static readonly string Photo_Friends_Name = "Друзья. Кафе";
    public static readonly string Photo_Friends_Description =
        "Трое парней с бокалами пива. Смеются.";
    public static readonly string Photo_Friends_Monologue =
        "Один в Австралии, один в Белграде, третий — я. " +
        "Разбросало нас по свету. " +
        "Смотрю на эту фотографию и думаю — мы ещё увидимся?";

    // ============================================================
    // РУКИ ГЕРОЯ (Особое событие)
    // ============================================================

    public static readonly string Hands_Name = "Посмотреть на руки";
    public static readonly string Hands_Monologue_Finger =
        "Палец потерял в девяностом. На учениях в Делницах, в Хорватии. " +
        "Несчастный случай — рванул предохранитель, зажало механизмом. Гангрена началась. " +
        "Полевой хирург сказал — повезло, что руку целиком спасли. Отрезали только палец.";
    public static readonly string Hands_Monologue_Scar =
        "А это — с Косова. Тоже девяностый. Патруль, албанские боевики, нож. " +
        "Успел увернуться, но достали. Повезло — сантиметром выше, и всё. " +
        "Отлежал в госпитале, вернулся в строй.";
    public static readonly string Hands_Monologue_Conclusion =
        "Теперь вот сижу, смотрю на свои руки. И думаю: стране, похоже, отрезают не пальцы. " +
        "Ей уже руки отрезают. Словению отрезали. Хорватию отрезают. " +
        "Босния... Босния пока дышит. Но тоже вся в трещинах, как мой потолок.";
}
