using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// АТМОСФЕРНЫЕ NPC
/// Не квестовые персонажи — просто живые детали мира.
/// Можно подойти и услышать реплику. Повторно — другая реплика.
/// 
/// Использование:
/// — Мужик на скамейке с бутылкой
/// — Бабка с авоськой
/// — Дети во дворе
/// — Мужик у подъезда с газетой
/// 
/// Вешается на каждого NPC.
/// NPC не движется — стоит/сидит на месте.
/// </summary>
public class AtmosphericNPC : MonoBehaviour
{
    [Header("Персонаж")]
    [SerializeField] private string npcName = "Прохожий";
    [SerializeField] private string lookAtHint = "[E] Посмотреть";

    [Header("Реплики (показываются по кругу)")]
    [TextArea(2, 5)]
    [SerializeField] private List<string> phrases = new List<string>();

    [Header("Реплика героя про NPC (при наведении)")]
    [TextArea(2, 4)]
    [SerializeField] private string heroObservation = "";

    [Header("Звук")]
    [SerializeField] private AudioClip ambientSound;  // Звук персонажа (кашель, бурчание)
    [SerializeField] private AudioSource audioSource;

    private int currentPhraseIndex = 0;
    private float lastInteractTime = -10f;
    private float interactCooldown = 3f;  // Минимум 3 сек между репликами

    public void OnHover()
    {
        UIManager.Instance?.ShowInteractHint($"{lookAtHint}: {npcName}");
    }

    public void OnHoverExit()
    {
        UIManager.Instance?.HideInteractHint();

        // Показываем наблюдение героя при первом наведении
        if (!string.IsNullOrEmpty(heroObservation) && lastInteractTime < 0)
            UIManager.Instance?.ShowMonologue(heroObservation);
    }

    public void OnInteract()
    {
        if (Time.time - lastInteractTime < interactCooldown) return;
        if (phrases.Count == 0) return;

        lastInteractTime = Time.time;

        string phrase = phrases[currentPhraseIndex % phrases.Count];
        currentPhraseIndex++;

        // Показываем реплику как диалог
        UIManager.Instance?.ShowNPCDialogue(npcName, phrase);

        // Воспроизводим звук
        if (ambientSound != null && audioSource != null)
            audioSource.PlayOneShot(ambientSound);
    }
}
