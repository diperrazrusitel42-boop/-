using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// КИНЕМАТОГРАФИЧЕСКАЯ КАМЕРА
/// Управляет движением камеры во время вступительной сцены.
/// 
/// Настройка:
/// Для каждой точки камеры (потолок, подоконник, окно и т.д.)
/// создайте пустой объект в сцене и назначьте его в Inspector.
/// Камера будет плавно перемещаться между этими точками.
/// </summary>
public class CinematicCamera : MonoBehaviour
{
    /// <summary>
    /// Точки в пространстве куда смотрит/движется камера
    /// </summary>
    public enum CameraTarget
    {
        Ceiling,           // Потолок (начальная позиция)
        WallWithWallpaper, // Стена с обоями
        Window,            // Окно
        Windowsill,        // Подоконник
        Bedroom,           // Комната в целом
        Bedside,           // Тумбочка у кровати
        StandUp,           // Момент когда герой встаёт
    }

    [Header("=== ТОЧКИ КАМЕРЫ ===")]
    [Header("Создайте пустые объекты в сцене и назначьте их сюда")]
    [SerializeField] private Transform pointCeiling;
    [SerializeField] private Transform pointWallWithWallpaper;
    [SerializeField] private Transform pointWindow;
    [SerializeField] private Transform pointWindowsill;
    [SerializeField] private Transform pointBedroom;
    [SerializeField] private Transform pointBedside;
    [SerializeField] private Transform pointStandUp;

    [Header("=== ТОЧКИ ФОКУСА НА ПРЕДМЕТАХ ===")]
    [Header("Создайте пустые объекты рядом с каждым предметом")]
    [SerializeField] private Transform focusNewspaper;
    [SerializeField] private Transform focusMug;
    [SerializeField] private Transform focusCigarette;
    [SerializeField] private Transform focusElectricBill;
    [SerializeField] private Transform focusSpoon;
    [SerializeField] private Transform focusMedicine;
    [SerializeField] private Transform focusMoney;

    [Header("=== НАСТРОЙКИ ДВИЖЕНИЯ ===")]
    [SerializeField] private float defaultPanSpeed = 1f;    // Скорость панорамирования
    [SerializeField] private AnimationCurve moveCurve;      // Кривая плавности движения

    [Header("=== ФЛЭШБЕК ===")]
    [SerializeField] private GameObject flashbackCamera;    // Отдельная камера для флэшбека
    [SerializeField] private GameObject mainCamera;         // Основная кинематографическая камера

    // Словарь точек камеры
    private Dictionary<CameraTarget, Transform> cameraPoints;

    void Start()
    {
        // Инициализируем словарь точек
        cameraPoints = new Dictionary<CameraTarget, Transform>
        {
            { CameraTarget.Ceiling,           pointCeiling },
            { CameraTarget.WallWithWallpaper, pointWallWithWallpaper },
            { CameraTarget.Window,            pointWindow },
            { CameraTarget.Windowsill,        pointWindowsill },
            { CameraTarget.Bedroom,           pointBedroom },
            { CameraTarget.Bedside,           pointBedside },
            { CameraTarget.StandUp,           pointStandUp },
        };

        // Начинаем с потолка
        if (pointCeiling != null)
        {
            transform.position = pointCeiling.position;
            transform.rotation = pointCeiling.rotation;
        }

        // Убеждаемся что флэшбек камера выключена
        if (flashbackCamera != null)
            flashbackCamera.SetActive(false);
    }

    /// <summary>
    /// Мгновенно установить камеру в позицию
    /// </summary>
    public void SetTarget(CameraTarget target)
    {
        if (!cameraPoints.ContainsKey(target)) return;
        Transform point = cameraPoints[target];
        if (point == null) return;

        transform.position = point.position;
        transform.rotation = point.rotation;
    }

    /// <summary>
    /// Плавное перемещение камеры к точке
    /// </summary>
    public IEnumerator PanTo(CameraTarget target, float duration)
    {
        if (!cameraPoints.ContainsKey(target)) yield break;
        Transform point = cameraPoints[target];
        if (point == null) yield break;

        yield return StartCoroutine(MoveCamera(
            transform.position, transform.rotation,
            point.position, point.rotation,
            duration
        ));
    }

    /// <summary>
    /// Плавный фокус на конкретный предмет на подоконнике
    /// </summary>
    public IEnumerator FocusOnItem(string itemName)
    {
        Transform focusPoint = GetFocusPoint(itemName);
        if (focusPoint == null) yield break;

        yield return StartCoroutine(MoveCamera(
            transform.position, transform.rotation,
            focusPoint.position, focusPoint.rotation,
            1.5f // Плавный переход 1.5 секунды
        ));
    }

    Transform GetFocusPoint(string itemName)
    {
        switch (itemName)
        {
            case "Newspaper":    return focusNewspaper;
            case "Mug":          return focusMug;
            case "Cigarette":    return focusCigarette;
            case "ElectricBill": return focusElectricBill;
            case "Spoon":        return focusSpoon;
            case "Medicine":     return focusMedicine;
            case "Money":        return focusMoney;
            default:
                Debug.LogWarning($"[Камера] Точка фокуса не найдена: {itemName}");
                return null;
        }
    }

    /// <summary>
    /// Включить/выключить режим флэшбека
    /// </summary>
    public void SetFlashbackMode(bool isFlashback)
    {
        if (mainCamera != null)
            mainCamera.SetActive(!isFlashback);

        if (flashbackCamera != null)
            flashbackCamera.SetActive(isFlashback);
    }

    /// <summary>
    /// Плавное движение камеры от A к B
    /// </summary>
    IEnumerator MoveCamera(
        Vector3 startPos, Quaternion startRot,
        Vector3 endPos, Quaternion endRot,
        float duration)
    {
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;

            // Плавность через кривую если назначена, иначе SmoothStep
            float smoothT = moveCurve != null && moveCurve.length > 0
                ? moveCurve.Evaluate(t)
                : Mathf.SmoothStep(0f, 1f, t);

            transform.position = Vector3.Lerp(startPos, endPos, smoothT);
            transform.rotation = Quaternion.Slerp(startRot, endRot, smoothT);

            yield return null;
        }

        // Гарантируем точное попадание в конечную позицию
        transform.position = endPos;
        transform.rotation = endRot;
    }
}
