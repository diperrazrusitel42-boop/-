using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// КОНТРОЛЛЕР МОНОЛОГОВ ГЕРОЯ
/// Хранит все тексты монологов и управляет их отображением
/// Все тексты монологов редактируются прямо здесь (сценаристом)
/// 
/// Вешается на объект MonologueController в сцене
/// </summary>
public class MonologueController : MonoBehaviour
{
    /// <summary>
    /// ID всех монологов в игре
    /// Чтобы добавить новый: добавьте ID сюда и текст в словарь ниже
    /// </summary>
    public enum MonologueID
    {
        // === СЦЕНА 1: ЧЁРНЫЙ ЭКРАН ===
        Scene1_City,

        // === СЦЕНА 2: ПОТОЛОК ===
        Scene2_Ceiling,
        Scene2_Empires,
        Scene2_Dust,

        // === СЦЕНА 3: ПОДОКОННИК ===
        Scene3_Newspaper,
        Scene3_Mug,
        Scene3_Cigarette,
        Scene3_ElectricBill,
        Scene3_Spoon,
        Scene3_Medicine,
        Scene3_Money,
        Scene3_MoneyAfterFlashback,

        // === ФЛЭШБЕКИ ===
        Flashback_Market,

        // === ТУМБОЧКА (комната героя) ===
        Room_DogTag,
        Room_MilitaryBook,
        Room_Photo_Army,
        Room_Diploma,
        Room_MissingFinger,
        Room_Scar,
        Room_Conclusion,
    }

    [Header("UI")]
    [SerializeField] private Text monologueText;
    [SerializeField] private GameObject monologuePanel;

    [Header("Настройки отображения")]
    [SerializeField] private float typingSpeed = 0.03f;       // Скорость печати текста
    [SerializeField] private float displayTime = 5f;           // Время показа после печати

    // Словарь всех монологов
    // СЦЕНАРИСТ РЕДАКТИРУЕТ ТЕКСТЫ ЗДЕСЬ:
    private Dictionary<MonologueID, string> monologues;

    private Coroutine currentMonologue;

    void Awake()
    {
        InitializeMonologues();
    }

    void InitializeMonologues()
    {
        monologues = new Dictionary<MonologueID, string>
        {
            // ========================================
            // СЦЕНА 1: ЧЁРНЫЙ ЭКРАН
            // ========================================
            [MonologueID.Scene1_City] =
                "Иногда мне кажется, что весь город замер. Как будто кто-то нажал на паузу. " +
                "А мы все сидим и ждём, когда нажмут «плей».",

            // ========================================
            // СЦЕНА 2: ПОТОЛОК
            // ========================================
            [MonologueID.Scene2_Ceiling] =
                "Опять этот потолок. Я смотрю на него каждое утро уже два года. " +
                "И каждое утро трещина чуть шире. Как будто дом дышит, разваливается потихоньку.",

            [MonologueID.Scene2_Empires] =
                "Империи тоже не взрываются. Они не падают в одну ночь, как Берлинская стена по телевизору. " +
                "Это кино для дураков. Они сначала трескаются. Вот так, как этот потолок. " +
                "Маленькая трещина, потом ещё одна, потом сетка, потом — раз! — и всё рухнуло.",

            [MonologueID.Scene2_Dust] =
                "В этой пыли — всё, что было. Мои родители, моя молодость, моя страна. " +
                "Всё перемешалось и висит в воздухе. Вдохнёшь — и внутри оседает.",

            // ========================================
            // СЦЕНА 3: ПОДОКОННИК
            // ========================================
            [MonologueID.Scene3_Newspaper] =
                "Я читаю газеты каждое утро. Как молитву. Сначала кофе, потом газета. " +
                "Только кофе теперь не с чем пить, а газеты страшно читать.\n\n" +
                "Инфляция. Слово-то какое — холодное, медицинское. А на деле — это когда утром " +
                "буханка стоит десять динар, а вечером уже пятнадцать. " +
                "И ты думаешь: купить утром две и спрятать или подождать — вдруг подешевеет? Не подешевеет.",

            [MonologueID.Scene3_Mug] =
                "Эту кружку помню с детства. Отец из неё пил чай после работы. " +
                "Мама говорила: «Не бери папину кружку». А я брал. " +
                "Теперь папы нет, мамы нет, а кружка живёт. " +
                "И чай в ней уже не тот — вода из-под крана, с ржавчиной.",

            [MonologueID.Scene3_Cigarette] =
                "Он курил самокрутки. Говорил, так дешевле. Я пробовал крутить — не получается, " +
                "всё сыплется. Наверное, привычка нужна, или терпение. У меня терпения нет.",

            [MonologueID.Scene3_ElectricBill] =
                "Свет подорожает в три раза. Если не заплатишь — отключат. " +
                "А чем платить, если работы нет? " +
                "Лампочки будем жечь. Или свечки. Свечки, говорят, скоро тоже будут по талонам.",

            [MonologueID.Scene3_Money] =
                "Это моя зарплата за три месяца. Если поменять на марки — хватит на полмешка картошки. " +
                "Если оставить — через месяц можно будет купить только спички. " +
                "Деньги тают быстрее снега в марте.",

            [MonologueID.Scene3_MoneyAfterFlashback] =
                "В этой стране теперь всё можно купить. И всё можно продать. " +
                "Вопрос только — за сколько. И есть ли у тебя то, что нужно другим.",

            // ========================================
            // ФЛЭШБЕКИ
            // ========================================
            [MonologueID.Flashback_Market] =
                "Я видел мужика на рынке. Он менял новую машину на мешок картошки. " +
                "И никто не улыбнулся. Потому что картошка — это жизнь. А машина — просто железо.",

            // ========================================
            // КОМНАТА ГЕРОЯ: ТУМБОЧКА
            // ========================================
            [MonologueID.Room_DogTag] =
                "Алюминиевый, потёртый, с выбитым номером. " +
                "Если меня убьют, по нему опознают. Если найдут, конечно.",

            [MonologueID.Room_MilitaryBook] =
                "Красно-коричневая обложка, герб СФРЮ. Потрёпанная, засаленная пальцами. " +
                "Там записано: участвовал в учениях на Маньяче, на Косове, в Словении. " +
                "Выбыл в запас в звании рядового.",

            [MonologueID.Room_Photo_Army] =
                "Это учения в Боснии, восемьдесят девятый. Мороз был под тридцать, а мы ползли по снегу. " +
                "Командир кричал: «Родина в опасности!» Мы смеялись. Теперь не до смеха.",

            [MonologueID.Room_Diploma] =
                "Слесарь-ремонтник, третий разряд. Хорошая профессия. Земная. " +
                "Токарный станок не спросит, кто ты по национальности, за кого голосовал. " +
                "Ему всё равно. Лишь бы руки были прямые.",

            [MonologueID.Room_MissingFinger] =
                "Палец потерял в девяностом. На учениях в Делницах, в Хорватии. " +
                "Несчастный случай — рванул предохранитель, зажало механизмом. Гангрена началась. " +
                "Полевой хирург сказал — повезло, что руку целиком спасли. Отрезали только палец.",

            [MonologueID.Room_Scar] =
                "А это — с Косова. Тоже девяностый. Патруль, албанские боевики, нож. " +
                "Успел увернуться, но достали. Повезло — сантиметром выше, и всё, кирдык. " +
                "Отлежал в госпитале, вернулся в строй.",

            [MonologueID.Room_Conclusion] =
                "Теперь вот сижу, смотрю на свои руки. И думаю: стране, похоже, отрезают не пальцы. " +
                "Ей уже руки отрезают. Словению отрезали. Хорватию отрезают. " +
                "Босния... Босния пока дышит. Но тоже вся в трещинах, как мой потолок.",
        };
    }

    /// <summary>
    /// Воспроизвести монолог по ID
    /// </summary>
    public void PlayMonologue(MonologueID id)
    {
        if (!monologues.ContainsKey(id))
        {
            Debug.LogWarning($"[Монолог] Текст не найден: {id}");
            return;
        }

        if (currentMonologue != null)
            StopCoroutine(currentMonologue);

        currentMonologue = StartCoroutine(ShowMonologue(monologues[id]));
    }

    IEnumerator ShowMonologue(string text)
    {
        if (monologuePanel != null)
            monologuePanel.SetActive(true);

        if (monologueText != null)
        {
            monologueText.text = "";

            // Печатаем по буквам
            foreach (char c in text)
            {
                monologueText.text += c;
                yield return new WaitForSeconds(typingSpeed);
            }
        }

        yield return new WaitForSeconds(displayTime);

        if (monologuePanel != null)
            monologuePanel.SetActive(false);
    }

    /// <summary>
    /// Мгновенно остановить текущий монолог
    /// </summary>
    public void StopCurrentMonologue()
    {
        if (currentMonologue != null)
        {
            StopCoroutine(currentMonologue);
            if (monologuePanel != null)
                monologuePanel.SetActive(false);
        }
    }
}
