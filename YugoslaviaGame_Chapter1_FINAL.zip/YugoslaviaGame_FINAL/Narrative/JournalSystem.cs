using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// ДНЕВНИК ГЕРОЯ
/// Автоматически фиксирует важные находки и события.
/// Открывается по клавише J.
/// Разделён на вкладки: Улики / Люди / Вопросы
///
/// Игрок видит мысли героя о том, что произошло.
/// Помогает не потерять нить сюжета в долгой игре.
/// </summary>
public class JournalSystem : MonoBehaviour
{
    public static JournalSystem Instance;

    public enum JournalTab { Clues, People, Questions }
    public enum EntryID
    {
        // УЛИКИ
        Clue_TrainPlan,          // Схема разгрузки поездов
        Clue_Letter,             // Письмо старика к семье
        Clue_Coordinates,        // Координаты с записки
        Clue_Notebook,           // Блокнот с цифрами 417
        Clue_Cigarette,          // Окурок (немецкий)
        Clue_Chain,              // Цепочка с распятием (если взял)
        Clue_FrenchWatch,        // Французские часы
        Clue_Money,              // Доллары из тайника

        // ЛЮДИ
        Person_OldMan,           // Старик (Милан Николич)
        Person_Shadow,           // Неизвестный из подъезда

        // ВОПРОСЫ
        Question_WhoKilled,      // Кто убил старика?
        Question_Bridge,         // Что будет с мостом?
        Question_Train417,       // Состав 417 — что везёт?
        Question_Cisterns,       // Чьи цистерны?
        Question_Miloran,        // Кто такой Милорад из объявления?
    }

    [Header("UI Дневника")]
    [SerializeField] private GameObject journalPanel;
    [SerializeField] private Transform entryContainer;       // Список записей
    [SerializeField] private GameObject entryPrefab;         // Prefab одной записи
    [SerializeField] private Text entryDetailText;           // Полный текст выбранной записи
    [SerializeField] private Text entryDetailTitle;
    [SerializeField] private Button tabClues;
    [SerializeField] private Button tabPeople;
    [SerializeField] private Button tabQuestions;

    private bool isOpen = false;
    private JournalTab currentTab = JournalTab.Clues;
    private List<JournalEntry> allEntries = new List<JournalEntry>();

    // Все тексты дневника
    private Dictionary<EntryID, JournalEntry> entryDatabase;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        InitDatabase();
    }

    void Start()
    {
        if (journalPanel != null) journalPanel.SetActive(false);
        tabClues?.onClick.AddListener(() => SwitchTab(JournalTab.Clues));
        tabPeople?.onClick.AddListener(() => SwitchTab(JournalTab.People));
        tabQuestions?.onClick.AddListener(() => SwitchTab(JournalTab.Questions));
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.J))
        {
            if (PauseMenuController.Instance == null || !PauseMenuController.Instance.IsPaused)
                ToggleJournal();
        }
    }

    void InitDatabase()
    {
        entryDatabase = new Dictionary<EntryID, JournalEntry>
        {
            // ================================
            // УЛИКИ
            // ================================
            [EntryID.Clue_TrainPlan] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Схема разгрузки поездов",
                date = "Октябрь 1991",
                text = "Старик вёл наблюдение за составами. Фиксировал содержимое — " +
                       "цистерны с топливом, крытые вагоны с «боеприпасами (?)». " +
                       "Состав 417 задержан на границе. На полях: " +
                       "«С запада идут эшелоны с оружием. Не для нас — ЧЕРЕЗ нас».\n\n" +
                       "Вопрос: кому адресовано оружие?"
            },

            [EntryID.Clue_Letter] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Письмо старика",
                date = "Октябрь 1991",
                text = "Нашёл под плинтусом. Писал своим, на случай смерти. " +
                       "Знал, что его убьют?\n\n" +
                       "Главное: «Через неделю перекроют мост. Город будет в блокаде».\n\n" +
                       "Если он прав — у нас 7 дней."
            },

            [EntryID.Clue_Coordinates] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Координаты. 44.82N 18.63E",
                date = "15 сентября 1991, 22:30",
                text = "Записка из ботинка старика. " +
                       "Дата — полтора месяца назад. Место — мост. Время — половина одиннадцатого.\n\n" +
                       "Что произошло на мосту в эту ночь?\n" +
                       "Цистерны. Кровь. Как в моём сне."
            },

            [EntryID.Clue_Notebook] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Цифры: 417-23-6-11-92",
                date = "Октябрь 1991",
                text = "Из блокнота. Состав 417 — это знакомо. " +
                       "23, 6, 11, 92 — что это? " +
                       "Вагоны? Координаты? Дата: 6 ноября 1992?\n\n" +
                       "Нужно разобраться."
            },

            [EntryID.Clue_Cigarette] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Окурок Marlboro в луже",
                date = "Октябрь 1991",
                text = "Немецкий акциз. Дорогие сигареты. " +
                       "Такая же пачка была у старика за холодильником. " +
                       "Совпадение? Или тот, кто убил старика, знал его лично?"
            },

            [EntryID.Clue_Chain] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Серебряная цепочка с распятием",
                date = "Октябрь 1991",
                text = "Упала у двери подъезда когда убегал. " +
                       "Тёплая — только что была на теле. " +
                       "Тонкая работа, не местная. Возможно, австрийская или немецкая."
            },

            [EntryID.Clue_FrenchWatch] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "Часы с гравировкой «Приятелю Николе»",
                date = "1989",
                text = "Французские, механические. Спрятаны под тумбочкой — значит дорогие " +
                       "не как вещь, а как секрет.\n\n" +
                       "Кто такой Никола? И кто подарил часы в 1989-м?"
            },

            [EntryID.Clue_Money] = new JournalEntry
            {
                tab = JournalTab.Clues,
                title = "100 долларов США (1988)",
                date = "Октябрь 1991",
                text = "Хранил годами. Не тратил даже когда инфляция пожирала всё. " +
                       "Это не сбережения — это последний выход. " +
                       "Он готовился бежать. Или готовился к чему-то хуже."
            },

            // ================================
            // ЛЮДИ
            // ================================
            [EntryID.Person_OldMan] = new JournalEntry
            {
                tab = JournalTab.People,
                title = "Милан Николич. Сосед",
                date = "",
                text = "70+ лет. Железнодорожник, 40 лет стажа. Вдовец.\n\n" +
                       "Верил в дружбу народов. Ненавидел националистов с обеих сторон.\n\n" +
                       "Последнее время вёл наблюдение за поездами. Звал меня зайти — " +
                       "говорил про «важные документы». Я не слушал.\n\n" +
                       "Убит. Профессионально."
            },

            [EntryID.Person_Shadow] = new JournalEntry
            {
                tab = JournalTab.People,
                title = "Неизвестный. Тень в подъезде",
                date = "Октябрь 1991",
                text = "Быстрый. Знал планировку подъезда — не запнулся в темноте. " +
                       "Уехал на старой «Заставе».\n\n" +
                       "Курил Marlboro с немецким акцизом. " +
                       "Оставил цепочку с распятием — случайно или нарочно?\n\n" +
                       "Мародёр? Или тот, кто убил старика и вернулся проверить?"
            },

            // ================================
            // ВОПРОСЫ
            // ================================
            [EntryID.Question_WhoKilled] = new JournalEntry
            {
                tab = JournalTab.Questions,
                title = "Кто убил старика?",
                date = "",
                text = "Профессиональный обыск. Ничего случайного. " +
                       "Искали конкретные бумаги — нашли или нет?\n\n" +
                       "Возможные версии:\n" +
                       "— Кто-то из власти (знал про поезда)\n" +
                       "— Криминал (деньги, оружие)\n" +
                       "— Военные (схема разгрузки)\n\n" +
                       "Тень с Marlboro — исполнитель или любопытный?"
            },

            [EntryID.Question_Bridge] = new JournalEntry
            {
                tab = JournalTab.Questions,
                title = "Мост. Через неделю — блокада?",
                date = "",
                text = "Старик был уверен. Писал как факт, не как слух.\n\n" +
                       "Если мост закроют — город отрежут. " +
                       "Продукты, лекарства, топливо — всё через этот мост.\n\n" +
                       "Нужно либо уйти, либо подготовиться. " +
                       "Либо выяснить — правда это или паранойя."
            },

            [EntryID.Question_Train417] = new JournalEntry
            {
                tab = JournalTab.Questions,
                title = "Состав 417. Что везёт?",
                date = "",
                text = "Задержан на границе. Старик выделил его красным.\n\n" +
                       "Цифры из блокнота: 417-23-6-11-92. " +
                       "Если 6.11.92 — дата... до неё больше года. Что произойдёт тогда?\n\n" +
                       "Нужно найти кого-то, кто знает железнодорожное расписание."
            },

            [EntryID.Question_Miloran] = new JournalEntry
            {
                tab = JournalTab.Questions,
                title = "Милорад из второго подъезда",
                date = "",
                text = "Объявление в подъезде: «Куплю патроны 12 калибра. Дорого. Срочно».\n\n" +
                       "Охотник готовится к сезону? " +
                       "Или кто-то готовится к другому сезону?\n\n" +
                       "Второй подъезд, квартира 8. Стучать вечером."
            },
        };
    }

    // ================================
    // ДОБАВЛЕНИЕ ЗАПИСЕЙ
    // ================================

    /// <summary>
    /// Добавить запись в дневник
    /// Вызывается автоматически при нахождении улик
    /// </summary>
    public void AddEntry(EntryID id)
    {
        if (!entryDatabase.ContainsKey(id)) return;
        if (allEntries.Exists(e => e.id == id)) return;

        var entry = entryDatabase[id];
        entry.id = id;
        allEntries.Add(entry);

        // Уведомление
        UIManager.Instance?.ShowMonologue($"Записано в дневник: {entry.title}");
        Debug.Log($"[Дневник] + {entry.title}");
    }

    // ================================
    // UI
    // ================================

    void ToggleJournal()
    {
        isOpen = !isOpen;

        if (journalPanel != null)
            journalPanel.SetActive(isOpen);

        if (isOpen)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);
            RefreshUI();
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);
        }
    }

    void SwitchTab(JournalTab tab)
    {
        currentTab = tab;
        RefreshUI();
    }

    void RefreshUI()
    {
        if (entryContainer == null || entryPrefab == null) return;

        foreach (Transform child in entryContainer)
            Destroy(child.gameObject);

        foreach (var entry in allEntries)
        {
            if (entry.tab != currentTab) continue;

            GameObject obj = Instantiate(entryPrefab, entryContainer);
            Text[] texts = obj.GetComponentsInChildren<Text>();
            if (texts.Length >= 1) texts[0].text = entry.title;
            if (texts.Length >= 2 && !string.IsNullOrEmpty(entry.date))
                texts[1].text = entry.date;

            Button btn = obj.GetComponent<Button>();
            var capturedEntry = entry;
            btn?.onClick.AddListener(() => ShowEntryDetail(capturedEntry));
        }
    }

    void ShowEntryDetail(JournalEntry entry)
    {
        if (entryDetailTitle != null) entryDetailTitle.text = entry.title;
        if (entryDetailText != null)  entryDetailText.text = entry.text;
    }
}

[System.Serializable]
public class JournalEntry
{
    public JournalSystem.EntryID id;
    public JournalSystem.JournalTab tab;
    public string title;
    public string date;
    [TextArea(3, 10)]
    public string text;
}
