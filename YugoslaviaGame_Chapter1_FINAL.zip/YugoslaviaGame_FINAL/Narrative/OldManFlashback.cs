using UnityEngine;
using System.Collections;

/// <summary>
/// ФЛЭШБЕК С ЖИВЫМ СОСЕДОМ (Сцена 6)
/// Когда игрок подходит к двери соседа — воспоминание.
/// Старик живой, курит на лестнице, разговаривает.
/// 
/// Это критически важная сцена: игрок должен полюбить
/// старика ДО того как увидит его тело.
/// </summary>
public class OldManFlashback : MonoBehaviour
{
    [Header("Триггер")]
    [SerializeField] private bool hasTriggered = false;

    [Header("Объекты флэшбека")]
    [SerializeField] private GameObject oldManAlive;     // Модель живого старика
    [SerializeField] private BlackScreenController blackScreen;
    [SerializeField] private MonologueController monologue;

    [Header("Монологи флэшбека")]
    [TextArea(2, 5)]
    [SerializeField] private string mono_Approach =
        "Дверь напротив. Сосед.";

    [TextArea(2, 5)]
    [SerializeField] private string mono_Memory1 =
        "Он на железной дороге работал. Сорок лет. " +
        "Стрелочником начинал, потом составителем, потом диспетчером. " +
        "Знал все составы наизусть.";

    [TextArea(2, 5)]
    [SerializeField] private string mono_Memory2 =
        "Хмурый был. Вечно ворчал. На молодёжь, на власть, на то, " +
        "что поезда ходить стали хуже, что графики срываются.";

    [TextArea(2, 5)]
    [SerializeField] private string mono_Memory3 =
        "Но в дружбу народов верил. Искренне. Говорил: " +
        "«Я серб, а мой напарник Боро — хорват. " +
        "Мы двадцать лет вместе составы гоняли. Дружили семьями. " +
        "А теперь — границы, таможни, визы... Безумие».";

    [TextArea(2, 5)]
    [SerializeField] private string mono_Memory4 =
        "Последнее время звал меня зайти. Говорил: " +
        "«Документы важные. Для истории. Надо сохранить, пока не сожгли». " +
        "Я отмахивался. Думал — старческий маразм.";

    [TextArea(2, 5)]
    [SerializeField] private string mono_Return =
        "А сегодня — дверь открыта.";

    [Header("Реплики старика во флэшбеке")]
    [SerializeField] private string[] oldManLines = {
        "Слышишь? Ночью снова шли. Без маркировки.",
        "Я записал. Всё записал. Когда уйду — не потеряется.",
        "Береги себя, сынок. Времена меняются быстро.",
    };

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasTriggered) return;
        hasTriggered = true;
        StartCoroutine(PlayFlashback());
    }

    IEnumerator PlayFlashback()
    {
        // Первый монолог — просто мысль
        UIManager.Instance?.ShowMonologue(mono_Approach);
        yield return new WaitForSeconds(3f);

        // Затемнение — уходим в воспоминание
        yield return StartCoroutine(blackScreen.FadeIn(0.8f));
        yield return new WaitForSeconds(0.3f);

        // Активируем живого старика
        if (oldManAlive != null) oldManAlive.SetActive(true);

        yield return StartCoroutine(blackScreen.FadeOut(1.5f));

        // Монологи про старика
        UIManager.Instance?.ShowMonologue(mono_Memory1);
        yield return new WaitForSeconds(7f);

        UIManager.Instance?.ShowMonologue(mono_Memory2);
        yield return new WaitForSeconds(6f);

        // Реплика самого старика
        UIManager.Instance?.ShowNPCDialogue("Михайло", oldManLines[0]);
        yield return new WaitForSeconds(5f);

        UIManager.Instance?.ShowMonologue(mono_Memory3);
        yield return new WaitForSeconds(8f);

        UIManager.Instance?.ShowNPCDialogue("Михайло", oldManLines[1]);
        yield return new WaitForSeconds(5f);

        UIManager.Instance?.ShowMonologue(mono_Memory4);
        yield return new WaitForSeconds(7f);

        UIManager.Instance?.ShowNPCDialogue("Михайло", oldManLines[2]);
        yield return new WaitForSeconds(4f);

        // Возврат к настоящему
        yield return StartCoroutine(blackScreen.FadeIn(1f));

        if (oldManAlive != null) oldManAlive.SetActive(false);

        yield return StartCoroutine(blackScreen.FadeOut(1.5f));

        UIManager.Instance?.ShowMonologue(mono_Return);
        yield return new WaitForSeconds(4f);

        // Добавляем в дневник
        JournalSystem.Instance?.AddEntry(JournalSystem.EntryID.Person_OldMan);
    }
}
