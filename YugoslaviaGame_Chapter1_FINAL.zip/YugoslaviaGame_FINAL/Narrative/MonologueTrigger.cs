using UnityEngine;

/// <summary>
/// Триггер для автоматического монолога
/// Вешается на зону (невидимый коллайдер) в сцене
/// Когда игрок входит в зону - запускается монолог
/// Используется для кинематографических моментов
/// </summary>
public class MonologueTrigger : MonoBehaviour
{
    [Header("Монолог")]
    [TextArea(3, 10)]
    [SerializeField] private string monologueText = "Текст монолога...";

    [Header("Настройки")]
    [SerializeField] private bool triggerOnce = true;  // Сработать только один раз
    [SerializeField] private float delay = 0f;          // Задержка перед показом

    private bool hasTriggered = false;

    void OnTriggerEnter(Collider other)
    {
        // Проверяем что это игрок
        if (!other.CompareTag("Player")) return;

        // Проверяем что уже не срабатывал
        if (triggerOnce && hasTriggered) return;

        hasTriggered = true;

        if (delay > 0)
            Invoke(nameof(ShowMonologue), delay);
        else
            ShowMonologue();
    }

    void ShowMonologue()
    {
        UIManager.Instance?.ShowMonologue(monologueText);
    }
}
