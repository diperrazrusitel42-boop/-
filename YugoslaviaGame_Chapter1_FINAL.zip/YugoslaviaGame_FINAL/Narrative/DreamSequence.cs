using UnityEngine;
using System.Collections;

/// <summary>
/// СОН ГЕРОЯ
/// Запускается если игрок ложится на кровать (опциональное действие).
/// Кошмар с цистернами и стариком без лица.
/// Сон полностью кинематографический — управление отключено.
/// </summary>
public class DreamSequence : MonoBehaviour
{
    [Header("Компоненты")]
    [SerializeField] private BlackScreenController blackScreen;
    [SerializeField] private CinematicCamera dreamCamera;

    [Header("Визуальные эффекты сна")]
    [SerializeField] private Material dreamPostProcess;   // Материал постобработки (размытие, виньетка)
    [SerializeField] private AudioSource dreamAmbient;    // Тревожный фон сна
    [SerializeField] private AudioClip dreamMusic;        // Музыка кошмара

    [Header("Объекты сна")]
    [SerializeField] private GameObject dreamBridge;      // Мост во сне
    [SerializeField] private GameObject dreamOldMan;      // Силуэт старика (без лица)
    [SerializeField] private GameObject dreamCisterns;   // Цистерны в реке
    [SerializeField] private ParticleSystem bloodParticles; // Кровь из цистерн

    [Header("Монологи сна")]
    [TextArea(2, 6)]
    [SerializeField] private string dream_FallAsleep =
        "Я лёг. Закрыл глаза. Не думал, что засну...";

    [TextArea(2, 6)]
    [SerializeField] private string dream_Bridge =
        "Мне приснился старик. Он стоял на мосту, в своей железнодорожной форме, и махал рукой.";

    [TextArea(2, 6)]
    [SerializeField] private string dream_NoFace =
        "Я подошёл ближе, а он обернулся — и лица у него не было. Только тёмное пятно. " +
        "Он показал пальцем вниз, на реку.";

    [TextArea(2, 6)]
    [SerializeField] private string dream_Cisterns =
        "А там, в воде, плыли цистерны. И из них текла кровь. " +
        "Медленно, густо — как нефть. И запах... железа и земли.";

    [TextArea(2, 6)]
    [SerializeField] private string dream_WakeUp =
        "Я проснулся в холодном поту.\n\n" +
        "За окном уже темнело. Сколько я проспал? " +
        "Часы старика стояли. А мои — тоже.";

    private bool dreamTriggered = false;

    /// <summary>
    /// Запустить сон (вызывается из InteractableObject кровати)
    /// </summary>
    public void StartDream()
    {
        if (dreamTriggered) return;
        dreamTriggered = true;
        StartCoroutine(DreamRoutine());
    }

    IEnumerator DreamRoutine()
    {
        // Отключаем управление
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);

        // Монолог перед сном
        if (monologue != null)
        UIManager.Instance?.ShowMonologue(dream_FallAsleep);
        yield return new WaitForSeconds(4f);

        // Затемнение — засыпаем
        yield return StartCoroutine(blackScreen.FadeIn(2f));
        yield return new WaitForSeconds(1f);

        // Включаем атмосферу сна
        if (dreamAmbient != null && dreamMusic != null)
        {
            dreamAmbient.clip = dreamMusic;
            dreamAmbient.loop = true;
            dreamAmbient.volume = 0.4f;
            dreamAmbient.Play();
        }

        // Активируем объекты сна
        if (dreamBridge != null) dreamBridge.SetActive(true);
        if (dreamOldMan != null) dreamOldMan.SetActive(true);

        // Проявляем сон
        yield return StartCoroutine(blackScreen.FadeOut(2f));

        // ---- СОН: МОСТ ----
        UIManager.Instance?.ShowMonologue(dream_Bridge);
        yield return new WaitForSeconds(6f);

        // Камера приближается к старику
        // (CinematicCamera анимирует движение к dreamOldMan)

        // ---- СОН: СТАРИК БЕЗ ЛИЦА ----
        UIManager.Instance?.ShowMonologue(dream_NoFace);
        yield return new WaitForSeconds(5f);

        // ---- СОН: ЦИСТЕРНЫ ----
        if (dreamCisterns != null) dreamCisterns.SetActive(true);
        if (bloodParticles != null) bloodParticles.Play();

        UIManager.Instance?.ShowMonologue(dream_Cisterns);
        yield return new WaitForSeconds(7f);

        // Резкое пробуждение — мигание
        yield return StartCoroutine(blackScreen.FadeIn(0.1f));
        yield return new WaitForSeconds(0.05f);
        yield return StartCoroutine(blackScreen.FadeOut(0.1f));
        yield return new WaitForSeconds(0.05f);
        yield return StartCoroutine(blackScreen.FadeIn(0.1f));
        yield return new WaitForSeconds(0.3f);
        yield return StartCoroutine(blackScreen.FadeOut(1f));

        // Убираем сон
        if (dreamBridge != null)   dreamBridge.SetActive(false);
        if (dreamOldMan != null)   dreamOldMan.SetActive(false);
        if (dreamCisterns != null) dreamCisterns.SetActive(false);
        if (dreamAmbient != null)  dreamAmbient.Stop();

        // ---- ПРОБУЖДЕНИЕ ----
        UIManager.Instance?.ShowMonologue(dream_WakeUp);
        yield return new WaitForSeconds(5f);

        // Возвращаем управление
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);

        // Сохраняем флаг
        SaveSystem.Instance?.SetFlag("dreamWatched", true);
    }
}
