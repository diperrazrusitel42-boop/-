using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// Контроллер чёрного экрана
/// Управляет fade-in / fade-out переходами
/// Вешается на Canvas → Panel (чёрный Image покрывающий весь экран)
/// </summary>
public class BlackScreenController : MonoBehaviour
{
    [SerializeField] private Image blackImage;  // Чёрный Image на весь экран

    void Awake()
    {
        if (blackImage == null)
            blackImage = GetComponent<Image>();
    }

    /// <summary>
    /// Мгновенно установить прозрачность (0 = прозрачный, 1 = чёрный)
    /// </summary>
    public void SetAlpha(float alpha)
    {
        if (blackImage == null) return;
        Color c = blackImage.color;
        c.a = alpha;
        blackImage.color = c;
        blackImage.gameObject.SetActive(alpha > 0.01f);
    }

    /// <summary>
    /// Плавное появление чёрного экрана (затемнение)
    /// </summary>
    public IEnumerator FadeIn(float duration)
    {
        if (blackImage == null) yield break;

        blackImage.gameObject.SetActive(true);
        float startAlpha = blackImage.color.a;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float alpha = Mathf.Lerp(startAlpha, 1f, elapsed / duration);
            SetAlpha(alpha);
            yield return null;
        }

        SetAlpha(1f);
    }

    /// <summary>
    /// Плавное исчезновение чёрного экрана (проявление)
    /// </summary>
    public IEnumerator FadeOut(float duration)
    {
        if (blackImage == null) yield break;

        blackImage.gameObject.SetActive(true);
        float startAlpha = blackImage.color.a;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float alpha = Mathf.Lerp(startAlpha, 0f, elapsed / duration);
            SetAlpha(alpha);
            yield return null;
        }

        SetAlpha(0f);
        blackImage.gameObject.SetActive(false);
    }
}
