using UnityEngine;
using System.Collections;

/// <summary>
/// ФИНАЛ ГЛАВЫ I — ВЫХОД НА УЛИЦУ (Сцена 9-10)
/// 
/// Запускается когда игрок выходит из подъезда.
/// Показывает финальный монолог и открывает мир (Chapter II).
/// </summary>
public class EndingChapter1 : MonoBehaviour
{
    [Header("Финальные монологи")]
    [TextArea(2, 8)]
    [SerializeField] private string monologue_Room =
        "Я зашёл в свою квартиру. Всё было на месте, но казалось чужим. " +
        "Стол, кровать, ковёр — как в музее.\n\n" +
        "Я сел на кровать и разложил находки.";

    [TextArea(2, 8)]
    [SerializeField] private string monologue_Items =
        "Письмо. «Через неделю перекроют мост. Город будет в блокаде.» " +
        "Он знал. И его убили за это знание. " +
        "Или за то, что он хотел рассказать.\n\n" +
        "Я посмотрел в окно. Город жил своей жизнью. " +
        "Никто не знал, что через неделю мост закроют. " +
        "Или знали, но молчали.";

    [TextArea(2, 8)]
    [SerializeField] private string monologue_Street =
        "Я вышел на крыльцо и остановился. " +
        "Воздух был сырым, пахло углём и выхлопными газами. " +
        "Мимо прошлёпала бабка с авоськой, глянула на меня подозрительно.\n\n" +
        "На скамейке у подъезда сидел мужик в телогрейке, курил «Дрину», смотрел в одну точку. " +
        "Рядом — пустая бутылка.\n\n" +
        "Где-то играло радио: «Продолжается заседание Президиума СФРЮ... " +
        "ситуация остаётся сложной... призываем к миру...»";

    [TextArea(2, 8)]
    [SerializeField] private string monologue_Final =
        "Город ещё не знает, что будет через неделю. Или знает, но молчит. " +
        "А я знаю. И не знаю, что делать с этим знанием.\n\n" +
        "Старик лежит наверху. Крысы бегают внизу. " +
        "А я стою между ними, с револьвером в кармане и чужими деньгами за пазухой.\n\n" +
        "С чего начать?";

    [Header("Настройки")]
    [SerializeField] private float delayBetweenMonologues = 8f;
    [SerializeField] private BlackScreenController blackScreen;

    private bool hasTriggered = false;

    /// <summary>
    /// Вызывается когда игрок нажимает "Выйти из подъезда"
    /// Или OnTriggerEnter если на двери стоит триггер
    /// </summary>
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (hasTriggered) return;

        hasTriggered = true;
        StartCoroutine(PlayEnding());
    }

    IEnumerator PlayEnding()
    {
        // Монолог в комнате (если игрок возвращался)
        UIManager.Instance?.ShowMonologue(monologue_Room);
        yield return new WaitForSeconds(delayBetweenMonologues);

        // Монолог про находки
        UIManager.Instance?.ShowMonologue(monologue_Items);
        yield return new WaitForSeconds(delayBetweenMonologues);

        // Монолог на улице
        UIManager.Instance?.ShowMonologue(monologue_Street);
        yield return new WaitForSeconds(delayBetweenMonologues);

        // Финальный монолог
        UIManager.Instance?.ShowMonologue(monologue_Final);
        yield return new WaitForSeconds(delayBetweenMonologues);

        // Открываем открытый мир
        StartCoroutine(OpenWorldTransition());
    }

    IEnumerator OpenWorldTransition()
    {
        // Плавное затемнение
        if (blackScreen != null)
            yield return StartCoroutine(blackScreen.FadeIn(2f));

        yield return new WaitForSeconds(1f);

        // Здесь будет загрузка следующей сцены
        // UnityEngine.SceneManagement.SceneManager.LoadScene("Chapter1_OpenWorld");

        Debug.Log("[ГЛАВА I ЗАВЕРШЕНА] Открытый мир разблокирован");

        // Пока просто показываем надпись
        UIManager.Instance?.ShowMonologue("ЧАСТЬ II");

        if (blackScreen != null)
            yield return StartCoroutine(blackScreen.FadeOut(2f));
    }
}
