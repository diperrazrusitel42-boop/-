using UnityEngine;

/// <summary>
/// ВИД ИЗ ОКНА НА ГОРОД (Сцена 5)
/// 
/// Игрок подходит к окну — автоматически запускаются
/// монологи про каждый элемент городской панорамы.
/// 
/// Для каждого объекта вдали (станция, заводы, река, мост)
/// создайте зону-триггер перед окном и назначьте MonologueTrigger.
/// 
/// ИЛИ: используйте этот скрипт на самом окне —
/// он последовательно показывает все монологи когда игрок подходит.
/// </summary>
public class CityWindowView : MonoBehaviour
{
    [Header("Монологи (последовательные)")]
    [TextArea(2, 6)]
    [SerializeField] private string monologue_Station =
        "Станция. Сортировочная. Отсюда поезда уходят на север, на юг, на запад. " +
        "Раньше тут было оживлённо — составы шли один за другим. " +
        "Теперь стоят. Говорят, скоро пойдут в другую сторону — с оружием.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Factory =
        "Заводы. Работают через пень-колоду. " +
        "Рабочих уже отправили в неоплачиваемый отпуск. " +
        "Стоят у ворот с плакатами: «Дайте работу!», «Хлеба и мира!». " +
        "Милиция разгоняет.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_River =
        "Река. Граница. Тот берег — уже Хорватия, а может, Босния. " +
        "Раньше мы ездили туда на пикники. Теперь через мост только с документами.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Bridge =
        "Колонны. По ночам идут. Военные грузовики, без опознавательных знаков. " +
        "Солдаты в штатском, с автоматами. Едут туда, где жарко.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Refugees =
        "А это наши новые жители. Беженцы. " +
        "Из Славонии, из Лики, из мест, где уже стреляют. " +
        "Местные их не любят. Говорят, приезжают и отнимают работу. " +
        "Какую работу? Работы нет.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_City =
        "Город живёт своей жизнью. Трамваи звякают, люди спешат по делам, " +
        "из ларьков играет музыка. " +
        "Никто не хочет замечать, что вокруг творится. " +
        "Или замечают, но делают вид, что это не с ними.";

    [TextArea(2, 6)]
    [SerializeField] private string monologue_Final =
        "Я стою у окна каждое утро и смотрю на это. " +
        "И думаю: когда же это кончится? Или только начинается?";

    [Header("Задержка между монологами (секунды)")]
    [SerializeField] private float delayBetweenMonologues = 7f;

    private bool hasTriggered = false;

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (hasTriggered) return;

        hasTriggered = true;
        StartCoroutine(PlayWindowSequence());
    }

    System.Collections.IEnumerator PlayWindowSequence()
    {
        string[] monologues = {
            monologue_Station,
            monologue_Factory,
            monologue_River,
            monologue_Bridge,
            monologue_Refugees,
            monologue_City,
            monologue_Final
        };

        foreach (string text in monologues)
        {
            UIManager.Instance?.ShowMonologue(text);
            yield return new WaitForSeconds(delayBetweenMonologues);
        }
    }
}
