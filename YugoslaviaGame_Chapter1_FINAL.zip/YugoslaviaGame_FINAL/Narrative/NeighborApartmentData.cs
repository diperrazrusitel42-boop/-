using UnityEngine;

/// <summary>
/// ДАННЫЕ ВСЕХ ПРЕДМЕТОВ В КВАРТИРЕ СОСЕДА И ПОДЪЕЗДЕ
/// Сцены 6, 7, 7B, 8 — подъезд, квартира, тело.
/// </summary>
public static class NeighborApartmentData
{
    // ============================================================
    // ПОДЪЕЗД — НАДПИСИ НА СТЕНАХ
    // ============================================================

    public static readonly string Wall_Graffiti1_Name = "Надпись на стене";
    public static readonly string Wall_Graffiti1_Description = "«СРБИЈА ДО ТОКИЈА» — синей краской, баллончиком.";
    public static readonly string Wall_Graffiti1_Monologue =
        "Кто-то поработал ночью. До Токио... " +
        "Смешно было бы, если бы не было так грустно.";

    public static readonly string Wall_Graffiti2_Name = "Надпись на стене";
    public static readonly string Wall_Graffiti2_Description = "Красным: «УСТАШЕ, ВРАЋАМО СЕ!»";
    public static readonly string Wall_Graffiti2_Monologue =
        "Усташи. Слово из войны, которая закончилась сорок лет назад. " +
        "Или не закончилась?";

    public static readonly string Wall_Pencil_Name = "Карандашная надпись";
    public static readonly string Wall_Pencil_Description = "Чуть в стороне, карандашом, неуверенным почерком.";
    public static readonly string Wall_Pencil_Content =
        "«Сви смо ми иста крв, зашто се убијамо?»\n\n" +
        "(Мы все одна кровь, зачем мы убиваем друг друга?)";
    public static readonly string Wall_Pencil_Monologue =
        "Кто-то написал карандашом. Аккуратно, как будто боялся. " +
        "Или стеснялся. Хороший вопрос, только отвечать некому.";

    // ============================================================
    // ПОДЪЕЗД — ОБЪЯВЛЕНИЯ
    // ============================================================

    public static readonly string Notice_Police_Name = "Объявление от милиции";
    public static readonly string Notice_Police_Content =
        "ГРАЖДАНЕ!\n\n" +
        "Будьте бдительны! В последнее время участились случаи квартирных краж " +
        "и разбойных нападений.\n\n" +
        "Милиция рекомендует не открывать дверь незнакомцам.\n\n" +
        "В случае подозрительных лиц звоните: 92\n\n" +
        "Дежурная часть работает круглосуточно.";
    public static readonly string Notice_Police_Monologue =
        "Объявление пожелтело, края отклеились. Повесили год назад. " +
        "С тех пор, говорят, лучше не стало.";

    public static readonly string Notice_Exchange_Name = "Объявление от жильца";
    public static readonly string Notice_Exchange_Content =
        "МЕНЯЮ квартиру (2 комн., 3 этаж) на дом в деревне.\n" +
        "СРОЧНО. Цена договорная.\n\n" +
        "Тел: [зачёркнуто]\n\n" +
        "[приписано от руки: «Уже уехал»]";
    public static readonly string Notice_Exchange_Monologue =
        "Уехал. Правильно сделал, наверное.";

    public static readonly string Notice_Bullets_Name = "Объявление о покупке патронов";
    public static readonly string Notice_Bullets_Content =
        "КУПЛЮ патроны 12 калибра.\n" +
        "Дорого. Срочно.\n\n" +
        "Спросить Милорада, 2-й подъезд, кв. 8.\n" +
        "Стучать вечером.";
    public static readonly string Notice_Bullets_Monologue =
        "Патроны. Дорого. Срочно. " +
        "Он охотник или уже нет?";

    public static readonly string Notice_Dog_Name = "Объявление о пропавшей собаке";
    public static readonly string Notice_Dog_Content =
        "ПРОПАЛА СОБАКА\n\n" +
        "Такса, 4 года, рыжая, отзывается на имя МАКС.\n\n" +
        "Пропала 15 октября, район улицы Братства.\n\n" +
        "Нашедшего прошу вернуть за вознаграждение.\n" +
        "Кв. 12, Ана.";
    public static readonly string Notice_Dog_Monologue =
        "Бумага свежая. Вчера повесили. " +
        "Бедный Макс.";

    // ============================================================
    // КВАРТИРА СОСЕДА — ПРИХОЖАЯ
    // ============================================================

    public static readonly string Apartment_Entry_Monologue =
        "Я толкнул дверь. Петли заскрипели, как будто их не смазывали сто лет. " +
        "В нос ударил запах — старый, затхлый, с нотками табака, мазута и ещё чего-то неуловимого. " +
        "Запах одинокой старости.\n\n" +
        "Внутри был погром. Но не пьяный разгром, а спокойный, деловой обыск. " +
        "Кто-то искал что-то конкретное и не спешил. " +
        "Мебель сдвинута, ящики вывалены, матрас разрезан, книги на полу. " +
        "Всё говорило о том, что здесь работали профессионалы.";

    // ---

    public static readonly string Mirror_Name = "Треснутое зеркало";
    public static readonly string Mirror_Description = "Треснутое, мутное. В нём отражается усталое лицо.";
    public static readonly string Mirror_Monologue =
        "На меня смотрит человек с кругами под глазами. " +
        "Я его знаю. Но сегодня — почти не узнаю.";

    public static readonly string Shoes_Name = "Старые ботинки";
    public static readonly string Shoes_Description = "Рабочие, потёртые. Внутри — стоптанные стельки.";
    public static readonly string Shoes_Monologue =
        "Сколько километров в этих ботинках пройдено. По перронам, по стрелкам, по грязи.";

    // ============================================================
    // КВАРТИРА СОСЕДА — КОМНАТА. ПРЕДМЕТЫ
    // ============================================================

    public static readonly string OldLetters_Name = "Пачка писем";
    public static readonly string OldLetters_Description =
        "Конверты, перевязанные бечёвкой. Письма от жены, из восьмидесятых.";
    public static readonly string OldLetters_Content =
        "Милан,\n\n" +
        "Как ты там? Скучаю. Дети спрашивают, когда папа приедет. " +
        "Я говорю — скоро. Приезжай скорее.\n\n" +
        "Картошку посадили, огород в порядке. " +
        "Сосед Стеван помог с забором.\n\n" +
        "Целую тебя крепко.\n" +
        "Твоя Марица\n\n" +
        "P.S. Привези детям что-нибудь из города, если можешь.";
    public static readonly string OldLetters_Monologue =
        "Письма от жены. Старые, из восьмидесятых. " +
        "Она умерла в восемьдесят шестом. Он хранил письма двадцать лет. " +
        "Двадцать лет перечитывал.";

    public static readonly string TrainPlan_Name = "Схема разгрузки поездов";
    public static readonly string TrainPlan_Description =
        "Лист А4, машинопись, пометки красным карандашом. Служебный документ.";
    public static readonly string TrainPlan_Content =
        "РАБОЧАЯ СХЕМА — СТАНЦИЯ [НАЗВАНИЕ ЗАКРЫТО]\n" +
        "Составитель: М. Николич\n" +
        "Дата: октябрь 1991\n\n" +
        "Состав 312 — цистерны — ТОПЛИВО (?)\n" +
        "Состав 415 — крытые вагоны — БОЕПРИПАСЫ (?)\n" +
        "Состав 417 — ЗАДЕРЖАН НА ГРАНИЦЕ\n" +
        "Состав 501 — прибыло из Словении — ПУСТЫЕ\n\n" +
        "[красным карандашом]\n" +
        "С запада идут эшелоны с оружием.\n" +
        "Не для нас — ЧЕРЕЗ нас.\n" +
        "Кто получатель???";
    public static readonly string TrainPlan_Monologue =
        "Он знал. Всё фиксировал, записывал. " +
        "Сорок лет на железной дороге — это сорок лет наблюдений. " +
        "И за что его убили?";

    // ============================================================
    // КВАРТИРА СОСЕДА — ТАЙНИКИ
    // ============================================================

    // Тайник 1: Револьвер за шкафом
    public static readonly string Revolver_Hidden_Prompt = "[E] Пощупать за шкафом";
    public static readonly string Revolver_Discover =
        "Рука нащупала что-то твёрдое, приклеенное к задней стенке. Скотч поддался с усилием.";
    public static readonly string Revolver_Name = "Револьвер";
    public static readonly string Revolver_Description =
        "Старый, с королевским гербом. Деревянная рукоять с трещиной. Тяжёлый, пахнет маслом. " +
        "Барабан пуст.";
    public static readonly string Revolver_Monologue =
        "Это не охотничье оружие. Это армейский. " +
        "Откуда он у железнодорожника на пенсии? " +
        "И почему спрятан, а не в ящике стола?";

    // Тайник 2: Патроны в матрасе
    public static readonly string Bullets_Hidden_Prompt = "[E] Нащупать внутри матраса";
    public static readonly string Bullets_Discover =
        "Пальцы нащупали холщовый мешочек. Металлический звон — патроны.";
    public static readonly string Bullets_Name = "Патроны 7.62 мм";
    public static readonly string Bullets_Description =
        "Холщовый мешочек, двенадцать патронов. Старые, но смазанные — блестят.";
    public static readonly string Bullets_Monologue =
        "Двенадцать патронов. Ровно двенадцать. " +
        "Он их считал.";

    // Тайник 3: Письмо под плинтусом
    public static readonly string Letter_Hidden_Prompt = "[E] Оторвать отошедший плинтус";
    public static readonly string Letter_Discover =
        "Плинтус отошёл легко — его уже отрывали раньше. Внутри тонкий листок.";
    public static readonly string Letter_Name = "Письмо старика к семье";
    public static readonly string Letter_Description =
        "Тонкий листок, карандаш. Буквы крупные, с нажимом — писал второпях.";
    public static readonly string Letter_Content =
        "Дорогие мои,\n\n" +
        "Если вы читаете это, значит, меня уже нет.\n\n" +
        "Через неделю перекроют мост. Город будет в блокаде. " +
        "Они думают, что я один это знаю. Но я записал всё.\n\n" +
        "Деньги я спрятал там же, где всегда.\n" +
        "Ключ от ящика — в почтовом ящике 17.\n\n" +
        "Прости меня.\n\n" +
        "Твой папа";
    public static readonly string Letter_Monologue =
        "Через неделю перекроют мост. Город будет в блокаде.\n" +
        "Он знал. И его убили за это знание.";

    // Тайник 4: Французские часы под крышкой тумбочки
    public static readonly string FrenchWatch_Hidden_Prompt = "[E] Посмотреть под крышкой тумбочки";
    public static readonly string FrenchWatch_Discover =
        "Под крышкой — кусок скотча и плоский предмет. Часы.";
    public static readonly string FrenchWatch_Name = "Французские часы";
    public static readonly string FrenchWatch_Description =
        "Механические, на кожаном ремешке. Идут, тикают. " +
        "На задней крышке гравировка: «Приятелю Николе, 1989».";
    public static readonly string FrenchWatch_Monologue =
        "Приятелю Николе. Кто такой Никола? " +
        "И почему эти часы спрятаны, а не носятся?";

    // Тайник 5: Деньги в полу (после прочтения письма)
    public static readonly string Money_Hidden_Prompt = "[E] Поднять половик и половицу";
    public static readonly string Money_Discover =
        "Под половицей — жестяная крышка. Под ней — углубление.";
    public static readonly string Money_Name = "100 долларов США";
    public static readonly string Money_Description =
        "Купюра 1988 года в целлофане. Чистая, без складок. " +
        "Целое состояние по нынешним меркам.";
    public static readonly string Money_Monologue =
        "Сто долларов. " +
        "Старик хранил их на чёрный день. " +
        "Вот и пришёл чёрный день.";

    // Немецкие сигареты за холодильником
    public static readonly string Cigarettes_Name = "Marlboro. Полная пачка";
    public static readonly string Cigarettes_Description =
        "Немецкий акциз. Дорогие. Откуда у пенсионера?";
    public static readonly string Cigarettes_Monologue =
        "Такие же сигареты были у тени в подъезде. " +
        "Или мне кажется?";

    // ============================================================
    // ТЕЛО СТАРИКА (СЦЕНА 8)
    // ============================================================

    public static readonly string Body_Entry_Monologue =
        "Он лежит на боку, подогнув ноги. Одна рука под туловищем, другая вытянута. " +
        "Голова повёрнута к стене. Лица не видно — только затылок с тёмным пятном. " +
        "Куртка — та самая, железнодорожная, с нашивками. " +
        "Если бы не она, я бы ни за что не узнал его.";

    public static readonly string Body_Face_Name = "Посмотреть на лицо";
    public static readonly string Body_Face_Monologue =
        "Я наклонился. Лицо разбито. Сплошное месиво. " +
        "Кровь, ссадины, опухоль. Нос свёрнут набок, губы разорваны, глаз заплыл. " +
        "Он упал лицом вниз, и каждая ступенька оставила свой след.";

    public static readonly string Body_Notebook_Name = "Блокнот из кармана";
    public static readonly string Body_Notebook_Description = "Маленький, в клетку. Страницы исписаны цифрами.";
    public static readonly string Body_Notebook_Content =
        "[последняя страница]\n\n" +
        "417 - 23 - 6 - 11 - 92\n\n" +
        "???";
    public static readonly string Body_Notebook_Monologue =
        "Цифры. Состав четыреста семнадцать. " +
        "Тот самый, что задержан на границе. " +
        "Что они означают?";

    public static readonly string Body_Note_Name = "Записка в ботинке";
    public static readonly string Body_Note_Description = "Под стелькой. Крошечный клочок бумаги.";
    public static readonly string Body_Note_Content =
        "15-09-91 / 22:30 / МОСТ / ЦИСТЕРНЫ\n\n" +
        "44.82N  18.63E";
    public static readonly string Body_Note_Monologue =
        "Координаты. Дата — пятнадцатое сентября. " +
        "Это уже было. Месяц назад. " +
        "Что происходило тогда на мосту в половину одиннадцатого ночи?";

    public static readonly string Body_Knife_Name = "Складной нож «Solingen»";
    public static readonly string Body_Knife_Description =
        "Деревянная рукоять. Лезвие острое, но механизм скрипит.";
    public static readonly string Body_Knife_Monologue =
        "Немецкий нож. Хорошая сталь. " +
        "Он не успел им воспользоваться.";

    public static readonly string Body_Conclusion_Monologue =
        "Я стоял над ним и смотрел.\n\n" +
        "Вспомнил, как он чинил мне кран в прошлом году. " +
        "Отказался от денег, только попросил папиросу. " +
        "Мы курили на лестнице, и он говорил о войне.\n\n" +
        "«Новая война будет хуже, — сказал он тогда. — " +
        "Потому что воевать будут соседи. " +
        "С кем ты пил ракию, с тем и будешь стреляться.»\n\n" +
        "Я не поверил. А теперь он лежит здесь. " +
        "И я держу в руках его тайны.";
}
