using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// ПОЧТОВЫЙ ЯЩИК №17
/// Ключ найден в кармане мёртвого старика.
/// Внутри — финальная улика первой главы.
///
/// Это кульминация перед выходом на улицу.
/// Ящик находится в холле подъезда, на первом этаже.
/// </summary>
public class MailboxEvent : MonoBehaviour
{
    [Header("Состояние")]
    [SerializeField] private bool isLocked = true;
    [SerializeField] private GameObject mailboxDoor;     // Дверца ящика (анимация открытия)
    [SerializeField] private GameObject contentsGroup;   // Содержимое ящика (скрыто)

    [Header("Содержимое ящика")]
    [SerializeField] private GameObject envelopeObject;  // Конверт внутри

    [Header("Звуки")]
    [SerializeField] private AudioClip lockSound;
    [SerializeField] private AudioClip openSound;
    [SerializeField] private AudioSource audioSource;

    [Header("Монологи")]
    [TextArea(2, 5)]
    [SerializeField] private string monologue_Locked =
        "Закрыт. Ключ бы найти...";

    [TextArea(2, 5)]
    [SerializeField] private string monologue_Opening =
        "Маленький ключ подошёл. Замок щёлкнул — старый, тугой, но поддался.";

    [TextArea(2, 5)]
    [SerializeField] private string monologue_Contents =
        "Внутри — конверт. Без марки, без адреса. " +
        "Просто написано от руки: «НАЙДЁШЬ — ПРОЧТИ».";

    private bool isOpen = false;

    public void OnHover()
    {
        if (isLocked)
        {
            bool hasKey = InventoryManager.Instance?.HasItem("Ключ от почтового ящика №17") ?? false;
            string hint = hasKey ? "[E] Открыть ящик №17" : "[E] Почтовый ящик №17 (закрыт)";
            UIManager.Instance?.ShowInteractHint(hint);
        }
        else if (!isOpen)
        {
            UIManager.Instance?.ShowInteractHint("[E] Заглянуть в ящик");
        }
    }

    public void OnHoverExit() => UIManager.Instance?.HideInteractHint();

    public void OnInteract()
    {
        if (isOpen) return;

        bool hasKey = InventoryManager.Instance?.HasItem("Ключ от почтового ящика №17") ?? false;

        if (isLocked && !hasKey)
        {
            UIManager.Instance?.ShowMonologue(monologue_Locked);
            return;
        }

        if (isLocked && hasKey)
        {
            StartCoroutine(OpenMailbox());
            return;
        }
    }

    IEnumerator OpenMailbox()
    {
        isLocked = false;

        // Звук замка
        if (lockSound != null && audioSource != null)
            audioSource.PlayOneShot(lockSound);

        UIManager.Instance?.ShowMonologue(monologue_Opening);
        yield return new WaitForSeconds(2f);

        // Анимация открытия дверцы
        if (mailboxDoor != null)
        {
            // Простая анимация: поворот дверцы
            float elapsed = 0f;
            Quaternion startRot = mailboxDoor.transform.localRotation;
            Quaternion endRot = Quaternion.Euler(0f, -90f, 0f);

            while (elapsed < 0.5f)
            {
                elapsed += Time.deltaTime;
                mailboxDoor.transform.localRotation = Quaternion.Lerp(startRot, endRot, elapsed / 0.5f);
                yield return null;
            }
        }

        // Звук открытия
        if (openSound != null && audioSource != null)
            audioSource.PlayOneShot(openSound);

        // Показываем содержимое
        if (contentsGroup != null) contentsGroup.SetActive(true);

        UIManager.Instance?.ShowMonologue(monologue_Contents);

        isOpen = true;

        // Добавляем запись в дневник
        JournalSystem.Instance?.AddEntry(JournalSystem.EntryID.Question_WhoKilled);
    }
}
