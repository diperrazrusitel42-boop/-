using UnityEngine;

/// <summary>
/// КОНТРОЛЛЕР ИГРОКА — ФИНАЛЬНАЯ ВЕРСИЯ
/// Вешается на объект Player вместе с CharacterController.
///
/// УПРАВЛЕНИЕ:
/// WASD / Стрелки — движение
/// Мышь           — осмотр
/// Shift          — бег
/// Ctrl           — присесть (замедление)
/// ESC            — разблокировать мышь (в редакторе)
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Скорости")]
    [SerializeField] private float walkSpeed   = 3.0f;
    [SerializeField] private float sprintSpeed = 5.5f;
    [SerializeField] private float crouchSpeed = 1.5f;

    [Header("Камера")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float mouseSensitivity = 2.0f;
    [SerializeField] private float maxLookAngle     = 80f;

    [Header("Физика")]
    [SerializeField] private float gravity        = -12f;
    [SerializeField] private float groundedForce  = -2f; // Прижимает к земле

    [Header("Покачивание при ходьбе")]
    [SerializeField] private bool  enableHeadBob   = true;
    [SerializeField] private float bobFrequency    = 2.0f;
    [SerializeField] private float bobAmplitude    = 0.04f;

    // ── ВНУТРЕННЕЕ ───────────────────────────────────────────
    private CharacterController _cc;
    private float _verticalVelocity;
    private float _rotationX;
    private bool  _movementEnabled = true;

    // Покачивание
    private float _bobTimer;
    private Vector3 _cameraOriginPos;

    void Start()
    {
        _cc = GetComponent<CharacterController>();
        if (!playerCamera) playerCamera = GetComponentInChildren<Camera>();

        _cameraOriginPos = playerCamera.transform.localPosition;

        LockCursor(true);
    }

    void Update()
    {
        if (!_movementEnabled) return;

        HandleMovement();
        HandleLook();
        if (enableHeadBob) HandleHeadBob();
    }

    // ─────────────────────────────────────────────────────────
    // ДВИЖЕНИЕ
    // ─────────────────────────────────────────────────────────
    void HandleMovement()
    {
        float speed = walkSpeed;
        if (Input.GetKey(KeyCode.LeftShift))   speed = sprintSpeed;
        if (Input.GetKey(KeyCode.LeftControl)) speed = crouchSpeed;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 move = transform.right * h + transform.forward * v;
        move = Vector3.ClampMagnitude(move, 1f); // нормализуем диагональ

        // Гравитация
        if (_cc.isGrounded)
            _verticalVelocity = groundedForce;
        else
            _verticalVelocity += gravity * Time.deltaTime;

        move.y = _verticalVelocity;
        _cc.Move(move * speed * Time.deltaTime);
    }

    // ─────────────────────────────────────────────────────────
    // ВЗГЛЯД
    // ─────────────────────────────────────────────────────────
    void HandleLook()
    {
        // Горизонталь — поворот тела
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        transform.Rotate(Vector3.up * mouseX);

        // Вертикаль — наклон камеры
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;
        _rotationX = Mathf.Clamp(_rotationX - mouseY, -maxLookAngle, maxLookAngle);
        playerCamera.transform.localRotation = Quaternion.Euler(_rotationX, 0f, 0f);
    }

    // ─────────────────────────────────────────────────────────
    // ПОКАЧИВАНИЕ КАМЕРЫ ПРИ ХОДЬБЕ
    // ─────────────────────────────────────────────────────────
    void HandleHeadBob()
    {
        bool isMoving = _cc.velocity.magnitude > 0.1f && _cc.isGrounded;

        if (isMoving)
        {
            _bobTimer += Time.deltaTime * bobFrequency;
            float bobY = Mathf.Sin(_bobTimer) * bobAmplitude;
            float bobX = Mathf.Cos(_bobTimer * 0.5f) * bobAmplitude * 0.5f;

            playerCamera.transform.localPosition = Vector3.Lerp(
                playerCamera.transform.localPosition,
                _cameraOriginPos + new Vector3(bobX, bobY, 0f),
                Time.deltaTime * 10f);
        }
        else
        {
            _bobTimer = 0f;
            playerCamera.transform.localPosition = Vector3.Lerp(
                playerCamera.transform.localPosition,
                _cameraOriginPos,
                Time.deltaTime * 8f);
        }
    }

    // ─────────────────────────────────────────────────────────
    // ПУБЛИЧНЫЕ МЕТОДЫ
    // ─────────────────────────────────────────────────────────
    public void SetMovementEnabled(bool enabled)
    {
        _movementEnabled = enabled;
        if (!enabled) LockCursor(false);
        else          LockCursor(true);
    }

    public void SetSensitivity(float value) => mouseSensitivity = value;

    public Camera GetCamera() => playerCamera;

    // ─────────────────────────────────────────────────────────
    void LockCursor(bool locked)
    {
        Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible   = !locked;
    }
}
