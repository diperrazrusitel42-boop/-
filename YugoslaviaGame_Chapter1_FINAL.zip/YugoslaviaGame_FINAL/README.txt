╔══════════════════════════════════════════════════════════════╗
║     YUGOSLAVIA GAME — ГЛАВА I. ЧАСТЬ I                      ║
║     ФИНАЛЬНАЯ ВЕРСИЯ ВСЕХ СКРИПТОВ                          ║
╚══════════════════════════════════════════════════════════════╝

38 скриптов. Все взаимосвязаны. Все протестированы на логику.

═══════════════════════════════════════════════════════════════
 СТРУКТУРА ПАПОК → КУДА КЛАСТЬ ФАЙЛЫ В UNITY
═══════════════════════════════════════════════════════════════

Assets/_Game/Scripts/
│
├── Core/               ← движок игры
│   ├── GameManager.cs          ★ ГЛАВНЫЙ — добавьте первым
│   ├── SaveSystem.cs           сохранения
│   ├── InventoryManager.cs     инвентарь
│   ├── DoorInteraction.cs      двери
│   ├── InspectObject3D.cs      осмотр в руках
│   ├── FilmGrainEffect.cs      зернистость
│   ├── RadioSystem.cs          радио
│   ├── AmbientSoundZone.cs     зоны звука
│   └── TimeOfDayLight.cs       освещение
│
├── Player/             ← всё для игрока
│   ├── PlayerController.cs     движение + камера + покачивание
│   └── InteractionSystem.cs    ← ВЕШАЕТСЯ ТОЖЕ НА ИГРОКА
│
├── Interaction/        ← предметы мира
│   ├── InteractableObject.cs   базовый предмет
│   ├── HiddenObject.cs         тайники
│   ├── ReadableObject.cs       читаемые документы
│   └── BodyInspector.cs        осмотр тела
│
├── Narrative/          ← история и атмосфера
│   ├── CinematicSequencer.cs   ★ режиссёр вступления
│   ├── CinematicCamera.cs      кинематографическая камера
│   ├── MonologueController.cs  монологи с текстами
│   ├── BlackScreenController.cs fade in/out
│   ├── AtmosphericAudio.cs     звуки вступления
│   ├── DreamSequence.cs        сон героя
│   ├── OldManFlashback.cs      флэшбек живого соседа
│   ├── ShadowEvent.cs          тень в подъезде
│   ├── CityWindowView.cs       вид из окна
│   ├── MailboxEvent.cs         почтовый ящик №17
│   ├── MailboxLetter.cs        содержимое письма
│   ├── EndingChapter1.cs       финал главы
│   ├── MonologueTrigger.cs     триггеры монологов
│   ├── AtmosphericNPC.cs       система NPC
│   ├── JournalSystem.cs        дневник (J)
│   ├── HeroRoomData.cs         ★ ВСЕ ТЕКСТЫ комнаты
│   ├── NeighborApartmentData.cs ★ ВСЕ ТЕКСТЫ квартиры
│   └── Chapter1NPCData.cs      ★ ВСЕ РЕПЛИКИ NPC
│
└── UI/                 ← интерфейс
    ├── UIManager.cs            ★ ГЛАВНЫЙ UI
    ├── ReadingUIController.cs  чтение документов
    ├── ChoiceUIManager.cs      моральный выбор
    ├── MainMenuController.cs   главное меню
    └── PauseMenuController.cs  пауза (ESC)

═══════════════════════════════════════════════════════════════
 ПЕРВЫЕ 5 ШАГОВ В UNITY
═══════════════════════════════════════════════════════════════

1. Создайте проект: Unity 2022+ → 3D (URP)

2. Создайте объект GameManager:
   - Hierarchy → Create Empty → "GameManager"
   - Add Component: GameManager, SaveSystem,
                    InventoryManager, JournalSystem
   - Это объект который живёт между сценами

3. Создайте Player:
   - Create Empty → "Player"
   - Add Component: CharacterController, PlayerController,
                    InteractionSystem
   - Внутри Player: Camera → "PlayerCamera", Y = 1.7

4. Создайте Canvas → добавьте UIManager:
   - Создайте все панели (см. SceneSetupGuide.cs)
   - Назначьте ссылки в Inspector UIManager

5. Нажмите Play — базовое движение работает

═══════════════════════════════════════════════════════════════
 КАК ДОБАВИТЬ ПРЕДМЕТ (быстрый гайд для сценариста)
═══════════════════════════════════════════════════════════════

1. Создайте куб в сцене (или импортируйте модель)
2. Add Component → InteractableObject
3. Заполните в Inspector:
   ┌─────────────────────────────────────────────┐
   │ objectName:     "Армейский жетон"           │
   │ description:    "Алюминиевый, потёртый..."  │
   │ innerMonologue: "Если меня убьют..."        │
   │ canPickUp:      ✓ (если берётся)            │
   │ canRead:        ✓ (если читается)           │
   │ canInspect3D:   ✓ (если крутить в руках)   │
   └─────────────────────────────────────────────┘
4. Установите Layer = "Interactable"

ВСЕ ТЕКСТЫ для предметов уже написаны в:
- HeroRoomData.cs        (комната героя)
- NeighborApartmentData.cs (квартира соседа)
- Chapter1NPCData.cs     (NPC)

═══════════════════════════════════════════════════════════════
 УПРАВЛЕНИЕ В ГОТОВОЙ ИГРЕ
═══════════════════════════════════════════════════════════════

  WASD        движение
  Мышь        осмотр
  E           взаимодействие
  Пробел      пропустить монолог
  F           закрыть документ / положить предмет
  I           инвентарь
  J           дневник (улики / люди / вопросы)
  ESC         пауза

═══════════════════════════════════════════════════════════════
 ЗВУКИ — ЧТО НУЖНО НАЙТИ (бесплатно на freesound.org)
═══════════════════════════════════════════════════════════════

  trainHorn        → "freight train horn distant"
  waterPipes       → "old pipes water gurgling"
  heatBattery      → "radiator heating creak"
  wind             → "wind howling old window"
  dogs             → "dogs barking distant night"
  rain             → "rain window autumn"
  doorCreak        → "old wooden door creak"
  footsteps        → "footsteps concrete"
  gunshot          → "revolver gunshot indoor"
  carEngine        → "old car engine start"
  buttonClick      → "typewriter key click"

═══════════════════════════════════════════════════════════════
