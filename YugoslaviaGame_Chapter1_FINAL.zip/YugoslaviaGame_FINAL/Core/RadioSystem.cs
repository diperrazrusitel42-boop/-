using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// СИСТЕМА РАДИО
/// Радио на кухне у героя и в подъезде.
/// Воспроизводит новостные репортажи и музыку эпохи.
/// Контент меняется в зависимости от прогресса игры.
///
/// Исторический контекст: октябрь 1991 — война в Хорватии,
/// Президиум СФРЮ, инфляция, беженцы.
/// </summary>
public class RadioSystem : MonoBehaviour
{
    public static RadioSystem Instance;

    [Header("Аудио")]
    [SerializeField] private AudioSource radioSource;
    [SerializeField] private List<AudioClip> newsClips;   // Записанные новости
    [SerializeField] private List<AudioClip> musicClips;  // Музыка эпохи
    [SerializeField] private float volume = 0.15f;        // Тихий фон

    [Header("Настройки")]
    [SerializeField] private float newsInterval = 120f;   // Новости каждые 2 минуты
    [SerializeField] private bool playOnStart = true;

    // Тексты новостей (субтитры если нет аудио)
    private List<string> newsTexts = new List<string>
    {
        "Продолжается заседание Президиума СФРЮ. Ситуация остаётся сложной. " +
        "Призываем все стороны к миру и диалогу.",

        "Инфляция в Югославии достигла двухсот процентов. " +
        "Национальный банк обещает стабилизационные меры.",

        "На хорватско-сербской границе продолжаются столкновения. " +
        "Число беженцев превысило двести тысяч человек.",

        "ЮНА объявила о введении чрезвычайных мер в ряде регионов. " +
        "Призываем граждан сохранять спокойствие.",

        "Европейское сообщество призвало к немедленному прекращению огня. " +
        "Переговоры продолжатся в Гааге.",

        "Состав рабочей группы по мирному урегулированию..." +
        " [помехи] ...ситуация в Славонии...",

        "Цены на хлеб вырастут с понедельника. " +
        "Местные власти обещают социальную поддержку малоимущим.",

        "Мост через реку будет закрыт для технического обслуживания. " +
        "Сроки уточняются.",
    };

    private int newsIndex = 0;
    private bool isOn = true;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        if (playOnStart)
            StartCoroutine(RadioRoutine());
    }

    IEnumerator RadioRoutine()
    {
        while (isOn)
        {
            // Играем музыку
            if (musicClips.Count > 0 && radioSource != null)
            {
                AudioClip music = musicClips[Random.Range(0, musicClips.Count)];
                radioSource.clip = music;
                radioSource.volume = volume;
                radioSource.Play();
                yield return new WaitForSeconds(music.length);
            }
            else
            {
                yield return new WaitForSeconds(newsInterval);
            }

            // Показываем новость (субтитры)
            if (newsIndex < newsTexts.Count)
            {
                string news = newsTexts[newsIndex % newsTexts.Count];
                newsIndex++;

                // Показываем как монолог (радио за стеной)
                UIManager.Instance?.ShowRadioSubtitle(news);

                // Если есть аудио новостей
                if (newsClips.Count > 0 && radioSource != null)
                {
                    AudioClip clip = newsClips[Random.Range(0, newsClips.Count)];
                    radioSource.clip = clip;
                    radioSource.Play();
                    yield return new WaitForSeconds(clip.length);
                }
                else
                {
                    yield return new WaitForSeconds(15f);
                }
            }
        }
    }

    public void TurnOff()
    {
        isOn = false;
        if (radioSource != null) radioSource.Stop();
    }

    public void TurnOn()
    {
        isOn = true;
        StartCoroutine(RadioRoutine());
    }
}
