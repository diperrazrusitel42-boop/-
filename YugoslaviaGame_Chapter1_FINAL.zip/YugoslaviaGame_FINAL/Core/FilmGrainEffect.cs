using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ЭФФЕКТ ЗЕРНИСТОСТИ ПЛЁНКИ
/// Создаёт ощущение старой советской кинохроники.
/// Вешается на Camera как компонент.
/// Работает через UI Image поверх экрана.
/// </summary>
public class FilmGrainEffect : MonoBehaviour
{
    [Header("Зернистость")]
    [SerializeField] private RawImage grainOverlay;   // UI Image поверх экрана
    [SerializeField] private float grainIntensity = 0.08f;
    [SerializeField] private float grainSpeed = 30f;  // Как быстро меняется зерно

    [Header("Виньетка")]
    [SerializeField] private Image vignetteOverlay;   // Тёмные углы
    [SerializeField] private float vignetteStrength = 0.4f;

    [Header("Горизонтальные полосы")]
    [SerializeField] private bool enableScanlines = true;
    [SerializeField] private float scanlineIntensity = 0.03f;

    private Texture2D grainTexture;
    private Color[] pixels;
    private int texSize = 128;

    void Start()
    {
        // Создаём текстуру зерна
        grainTexture = new Texture2D(texSize, texSize, TextureFormat.RGBA32, false);
        grainTexture.filterMode = FilterMode.Bilinear;
        pixels = new Color[texSize * texSize];

        if (grainOverlay != null)
        {
            grainOverlay.texture = grainTexture;
            grainOverlay.color = new Color(1f, 1f, 1f, grainIntensity);
        }

        // Настраиваем виньетку
        if (vignetteOverlay != null)
            vignetteOverlay.color = new Color(0f, 0f, 0f, vignetteStrength);

        // Проверяем настройки из PlayerPrefs
        bool grainEnabled = PlayerPrefs.GetInt("FilmGrain", 1) == 1;
        gameObject.SetActive(grainEnabled);
    }

    void Update()
    {
        // Обновляем зерно каждый кадр
        if (grainOverlay == null) return;

        for (int i = 0; i < pixels.Length; i++)
        {
            float noise = Random.Range(0f, 1f);
            pixels[i] = new Color(noise, noise, noise, 1f);
        }

        grainTexture.SetPixels(pixels);
        grainTexture.Apply();
    }
}
