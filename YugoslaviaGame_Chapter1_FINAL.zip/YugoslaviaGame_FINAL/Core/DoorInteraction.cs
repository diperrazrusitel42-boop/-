using UnityEngine;
using System.Collections;

/// <summary>
/// СИСТЕМА ДВЕРЕЙ
/// Двери которые можно открыть/закрыть.
/// С анимацией, звуком, и логикой блокировки.
///
/// Двери в главе I:
/// — Дверь героя (всегда открыта)
/// — Дверь соседа (приоткрыта, можно толкнуть)
/// — Дверь подъезда на улицу
/// — Шкаф в квартире соседа
/// </summary>
public class DoorInteraction : MonoBehaviour
{
    public enum DoorState { Closed, Open, Locked }

    [Header("Состояние")]
    [SerializeField] private DoorState initialState = DoorState.Closed;
    [SerializeField] private bool isAjar = false;      // Приоткрыта (как у соседа)

    [Header("Анимация")]
    [SerializeField] private float openAngle = 90f;    // Угол открытия
    [SerializeField] private float openSpeed = 2f;
    [SerializeField] private bool openInward = false;  // Открывается вовнутрь

    [Header("Подсказки")]
    [SerializeField] private string openHint = "[E] Открыть дверь";
    [SerializeField] private string closeHint = "[E] Закрыть дверь";
    [SerializeField] private string lockedHint = "[E] Заперто";
    [SerializeField] private string ajarHint = "[E] Толкнуть дверь";

    [Header("Монолог при входе")]
    [TextArea(2, 4)]
    [SerializeField] private string onOpenMonologue = "";

    [Header("Звуки")]
    [SerializeField] private AudioClip openSound;
    [SerializeField] private AudioClip closeSound;
    [SerializeField] private AudioClip lockedSound;
    [SerializeField] private AudioClip creakSound;    // Скрип (для приоткрытой)
    [SerializeField] private AudioSource audioSource;

    private DoorState currentState;
    private bool isAnimating = false;
    private Quaternion closedRotation;
    private Quaternion openRotation;

    void Start()
    {
        currentState = initialState;
        closedRotation = transform.localRotation;

        float angle = openInward ? -openAngle : openAngle;
        openRotation = closedRotation * Quaternion.Euler(0f, angle, 0f);

        // Если приоткрыта — ставим на небольшой угол
        if (isAjar)
        {
            transform.localRotation = closedRotation *
                Quaternion.Euler(0f, openAngle * 0.15f, 0f);
        }
    }

    public void OnHover()
    {
        string hint = currentState switch
        {
            DoorState.Locked => lockedHint,
            DoorState.Open => closeHint,
            _ => isAjar ? ajarHint : openHint,
        };
        UIManager.Instance?.ShowInteractHint(hint);
    }

    public void OnHoverExit() => UIManager.Instance?.HideInteractHint();

    public void OnInteract()
    {
        if (isAnimating) return;

        switch (currentState)
        {
            case DoorState.Locked:
                PlaySound(lockedSound);
                UIManager.Instance?.ShowMonologue("Заперто.");
                break;

            case DoorState.Closed:
                StartCoroutine(OpenDoor());
                break;

            case DoorState.Open:
                StartCoroutine(CloseDoor());
                break;
        }
    }

    IEnumerator OpenDoor()
    {
        isAnimating = true;

        // Звук скрипа если приоткрыта
        if (isAjar && creakSound != null)
            PlaySound(creakSound);
        else
            PlaySound(openSound);

        // Монолог при открытии
        if (!string.IsNullOrEmpty(onOpenMonologue))
            UIManager.Instance?.ShowMonologue(onOpenMonologue);

        // Анимация открытия
        yield return StartCoroutine(AnimateDoor(openRotation));

        currentState = DoorState.Open;
        isAjar = false;
        isAnimating = false;
    }

    IEnumerator CloseDoor()
    {
        isAnimating = true;
        PlaySound(closeSound);

        yield return StartCoroutine(AnimateDoor(closedRotation));

        currentState = DoorState.Closed;
        isAnimating = false;
    }

    IEnumerator AnimateDoor(Quaternion targetRotation)
    {
        Quaternion startRotation = transform.localRotation;
        float elapsed = 0f;
        float duration = 1f / openSpeed;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / duration);
            transform.localRotation = Quaternion.Slerp(startRotation, targetRotation, t);
            yield return null;
        }

        transform.localRotation = targetRotation;
    }

    void PlaySound(AudioClip clip)
    {
        if (clip != null && audioSource != null)
            audioSource.PlayOneShot(clip);
    }

    // Заблокировать/разблокировать дверь из другого скрипта
    public void SetLocked(bool locked)
    {
        currentState = locked ? DoorState.Locked : DoorState.Closed;
    }
}
