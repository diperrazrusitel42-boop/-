using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;

/// <summary>
/// СИСТЕМА СОХРАНЕНИЙ — ФИНАЛЬНАЯ ВЕРСИЯ
/// 3 слота + автосохранение каждые 5 минут.
/// Данные хранятся в JSON на диске.
/// Вешается на объект GameManager.
/// </summary>
public class SaveSystem : MonoBehaviour
{
    public static SaveSystem Instance { get; private set; }
    void Awake_Instance() { Instance = this; }
{
    [Header("Настройки")]
    [SerializeField] private int   totalSlots       = 3;
    [SerializeField] private float autoSaveInterval = 300f;

    private SaveData _current;
    private float    _playTimer;
    private float    _autoTimer;

    string SaveDir  => Application.persistentDataPath + "/saves/";
    string SlotPath(int i) => SaveDir + $"slot_{i}.json";

    void Start()
    {
        if (!Directory.Exists(SaveDir)) Directory.CreateDirectory(SaveDir);
    }

    void Update()
    {
        if (_current == null) return;
        _playTimer += Time.deltaTime;
        _autoTimer += Time.deltaTime;
        if (_autoTimer >= autoSaveInterval) { _autoTimer = 0f; AutoSave(); }
    }

    // ════════════════════════════════════════════════════════
    // СОХРАНЕНИЕ
    // ════════════════════════════════════════════════════════
    public void SaveToSlot(int slot)
    {
        if (_current == null || slot < 0 || slot >= totalSlots) return;
        Snapshot();
        File.WriteAllText(SlotPath(slot), JsonUtility.ToJson(_current, true));
        UIManager.Instance?.ShowNotification($"✓ Сохранено  {_current.dateTime}");
        Debug.Log($"[Save] Слот {slot+1} сохранён");
    }

    public void AutoSave()
    {
        if (_current == null) return;
        Snapshot();
        _current.slotName = "Автосохранение";
        File.WriteAllText(SlotPath(0), JsonUtility.ToJson(_current, true));
        Debug.Log("[Save] Автосохранение");
    }

    // ════════════════════════════════════════════════════════
    // ЗАГРУЗКА
    // ════════════════════════════════════════════════════════
    public bool LoadFromSlot(int slot)
    {
        string path = SlotPath(slot);
        if (!File.Exists(path)) return false;

        _current = JsonUtility.FromJson<SaveData>(File.ReadAllText(path));
        if (_current == null) return false;

        UnityEngine.SceneManagement.SceneManager
            .LoadScene(string.IsNullOrEmpty(_current.sceneName)
                ? "Chapter1_Apartment" : _current.sceneName);
        return true;
    }

    public void StartNewGame(int slot)
    {
        _current = new SaveData { slotName = $"Слот {slot+1}" };
        UnityEngine.SceneManagement.SceneManager.LoadScene("Chapter1_Apartment");
    }

    public void RestorePlayerPosition(PlayerController player)
    {
        if (_current == null || player == null) return;
        player.transform.SetPositionAndRotation(
            new Vector3(_current.px, _current.py, _current.pz),
            Quaternion.Euler(0, _current.pRotY, 0));
    }

    // ════════════════════════════════════════════════════════
    // СНИМОК СОСТОЯНИЯ
    // ════════════════════════════════════════════════════════
    void Snapshot()
    {
        _current.totalPlayTime += _playTimer; _playTimer = 0f;
        _current.dateTime  = DateTime.Now.ToString("dd.MM.yyyy  HH:mm");
        _current.sceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
        _current.chapter   = "Глава I";

        var player = FindObjectOfType<PlayerController>();
        if (player != null)
        {
            _current.px    = player.transform.position.x;
            _current.py    = player.transform.position.y;
            _current.pz    = player.transform.position.z;
            _current.pRotY = player.transform.eulerAngles.y;
        }

        // Инвентарь
        var inv = GameManager.Instance?.Inventory;
        if (inv != null)
        {
            _current.inventoryNames.Clear();
            _current.inventoryDescs.Clear();
            foreach (var item in inv.GetAllItems())
            {
                _current.inventoryNames.Add(item.name);
                _current.inventoryDescs.Add(item.description);
            }
        }
    }

    // ════════════════════════════════════════════════════════
    // ФЛАГИ ПРОГРЕССА
    // ════════════════════════════════════════════════════════
    public void SetFlag(string key, bool value)
    {
        if (_current == null) return;
        int idx = _current.flagKeys.IndexOf(key);
        if (idx < 0) { _current.flagKeys.Add(key); _current.flagValues.Add(value); }
        else _current.flagValues[idx] = value;
    }

    public bool GetFlag(string key)
    {
        if (_current == null) return false;
        int idx = _current.flagKeys.IndexOf(key);
        return idx >= 0 && _current.flagValues[idx];
    }

    public void MarkObjectInspected(string name)
    {
        if (_current != null && !_current.inspected.Contains(name))
            _current.inspected.Add(name);
    }

    public bool IsInspected(string name) =>
        _current?.inspected.Contains(name) ?? false;

    public void RecordChoice(string choice)
    {
        _current?.choices.Add(choice);
    }

    // ════════════════════════════════════════════════════════
    // ИНФОРМАЦИЯ О СЛОТАХ (для меню)
    // ════════════════════════════════════════════════════════
    public List<SaveSlotInfo> GetAllSlotsInfo()
    {
        var list = new List<SaveSlotInfo>();
        for (int i = 0; i < totalSlots; i++)
        {
            string path = SlotPath(i);
            if (!File.Exists(path))
            {
                list.Add(new SaveSlotInfo { slotIndex=i, isEmpty=true,
                    slotName=$"Слот {i+1}", dateTime="— пусто —" });
                continue;
            }
            var d = JsonUtility.FromJson<SaveData>(File.ReadAllText(path));
            list.Add(new SaveSlotInfo
            {
                slotIndex = i, isEmpty = false,
                slotName  = d.slotName,
                dateTime  = d.dateTime,
                chapter   = d.chapter,
                playTime  = FormatTime(d.totalPlayTime)
            });
        }
        return list;
    }

    public void DeleteSlot(int slot)
    {
        string path = SlotPath(slot);
        if (File.Exists(path)) File.Delete(path);
    }

    string FormatTime(float sec)
    {
        int h = (int)(sec / 3600), m = (int)((sec % 3600) / 60);
        return $"{h:00}:{m:00}";
    }
}

// ════════════════════════════════════════════════════════════
// СТРУКТУРА ДАННЫХ
// ════════════════════════════════════════════════════════════
[Serializable]
public class SaveData
{
    public string slotName       = "Слот";
    public string dateTime       = "";
    public string sceneName      = "";
    public string chapter        = "Глава I";
    public float  totalPlayTime  = 0f;

    // Позиция
    public float px, py, pz, pRotY;

    // Инвентарь
    public List<string> inventoryNames = new List<string>();
    public List<string> inventoryDescs = new List<string>();

    // Флаги прогресса (универсальный словарь)
    public List<string> flagKeys   = new List<string>();
    public List<bool>   flagValues = new List<bool>();

    // Осмотренные объекты
    public List<string> inspected = new List<string>();

    // Моральные выборы
    public List<string> choices = new List<string>();
}

[Serializable]
public class SaveSlotInfo
{
    public int    slotIndex;
    public bool   isEmpty;
    public string slotName, dateTime, chapter, playTime;
}
