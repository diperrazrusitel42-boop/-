using UnityEngine;

/// <summary>
/// ОСВЕЩЕНИЕ — УТРО, ОКТЯБРЬ 1991
/// Управляет светом в сцене для создания нужной атмосферы.
/// Пасмурное осеннее утро. Серое небо. Холодный свет.
///
/// Настройки для Directional Light:
/// Цвет: холодный серо-голубой
/// Интенсивность: 0.4 (пасмурно)
/// Тени: мягкие
/// </summary>
public class TimeOfDayLight : MonoBehaviour
{
    [Header("Направленный свет")]
    [SerializeField] private Light directionalLight;

    [Header("Цвет и интенсивность")]
    [SerializeField] private Color morningCloudyColor = new Color(0.7f, 0.75f, 0.85f);
    [SerializeField] private float morningIntensity = 0.45f;

    [Header("Ambient свет")]
    [SerializeField] private Color ambientColor = new Color(0.35f, 0.38f, 0.45f);

    [Header("Туман")]
    [SerializeField] private bool enableFog = true;
    [SerializeField] private Color fogColor = new Color(0.6f, 0.63f, 0.7f);
    [SerializeField] private float fogDensity = 0.02f;

    [Header("Лампочки в подъезде")]
    [SerializeField] private Light[] hallwayLights;     // Тусклые лампы дневного света
    [SerializeField] private float hallwayIntensity = 0.3f;
    [SerializeField] private Color hallwayColor = new Color(0.9f, 0.95f, 0.8f); // Желтоватый

    [Header("Мерцание ламп")]
    [SerializeField] private bool flickering = true;
    [SerializeField] private float flickerChance = 0.02f; // 2% вероятность мерцания

    void Start()
    {
        SetupMainLight();
        SetupAmbient();
        SetupFog();
        SetupHallwayLights();
    }

    void Update()
    {
        if (flickering) HandleFlicker();
    }

    void SetupMainLight()
    {
        if (directionalLight == null) return;
        directionalLight.color = morningCloudyColor;
        directionalLight.intensity = morningIntensity;
        directionalLight.shadowStrength = 0.6f;
        directionalLight.transform.rotation = Quaternion.Euler(25f, 150f, 0f);
    }

    void SetupAmbient()
    {
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = ambientColor;
    }

    void SetupFog()
    {
        if (!enableFog) return;
        RenderSettings.fog = true;
        RenderSettings.fogColor = fogColor;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = fogDensity;
    }

    void SetupHallwayLights()
    {
        if (hallwayLights == null) return;
        foreach (var light in hallwayLights)
        {
            if (light == null) continue;
            light.color = hallwayColor;
            light.intensity = hallwayIntensity;
            light.range = 4f;
        }
    }

    void HandleFlicker()
    {
        if (hallwayLights == null) return;
        foreach (var light in hallwayLights)
        {
            if (light == null) continue;
            if (Random.value < flickerChance)
            {
                light.intensity = Random.value < 0.5f
                    ? hallwayIntensity * 0.1f
                    : hallwayIntensity;
            }
        }
    }
}
