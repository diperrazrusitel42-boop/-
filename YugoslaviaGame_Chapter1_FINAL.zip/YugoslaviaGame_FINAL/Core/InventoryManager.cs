using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// ИНВЕНТАРЬ — ФИНАЛЬНАЯ ВЕРСИЯ
/// Клавиша I — открыть/закрыть.
/// Клик по предмету — показать описание справа.
/// </summary>
public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance { get; private set; }
    [Header("UI")]
    [SerializeField] private GameObject     inventoryPanel;
    [SerializeField] private Transform      listContainer;   // Список предметов
    [SerializeField] private GameObject     itemPrefab;      // Prefab строки списка
    [SerializeField] private Text           detailName;      // Имя выбранного
    [SerializeField] private Text           detailDesc;      // Описание выбранного

    private List<InventoryItem> _items = new List<InventoryItem>();
    private bool _isOpen = false;

    void Awake() { Instance = this; }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            bool paused = PauseMenuController.Instance != null
                       && PauseMenuController.Instance.IsPaused;
            if (!paused) Toggle();
        }
    }

    // ════════════════════════════════════════════════════════
    // ДОБАВЛЕНИЕ / ПРОВЕРКА
    // ════════════════════════════════════════════════════════
    public void AddItem(string name, string desc)
    {
        if (_items.Exists(i => i.name == name)) return;
        _items.Add(new InventoryItem(name, desc));

        UIManager.Instance?.ShowNotification($"+  {name}");
        GameManager.Instance?.Save.MarkObjectInspected(name);

        if (_isOpen) Refresh();
        Debug.Log($"[Инвентарь] + {name}");
    }

    public bool HasItem(string name)          => _items.Exists(i => i.name == name);
    public List<InventoryItem> GetAllItems()  => _items;

    public void LoadItems(List<string> names, List<string> descs)
    {
        _items.Clear();
        for (int i = 0; i < names.Count && i < descs.Count; i++)
            _items.Add(new InventoryItem(names[i], descs[i]));
        if (_isOpen) Refresh();
    }

    // ════════════════════════════════════════════════════════
    // UI
    // ════════════════════════════════════════════════════════
    void Toggle()
    {
        _isOpen = !_isOpen;
        inventoryPanel?.SetActive(_isOpen);

        if (_isOpen)
        {
            Refresh();
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible   = true;
            FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible   = false;
            FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);
        }
    }

    void Refresh()
    {
        if (!listContainer || !itemPrefab) return;
        foreach (Transform t in listContainer) Destroy(t.gameObject);

        foreach (var item in _items)
        {
            var go  = Instantiate(itemPrefab, listContainer);
            var txt = go.GetComponentInChildren<Text>();
            if (txt) txt.text = item.name;

            string n = item.name, d = item.description;
            go.GetComponent<Button>()?.onClick.AddListener(() =>
            {
                if (detailName) detailName.text = n;
                if (detailDesc) detailDesc.text = d;
            });
        }
    }
}

[System.Serializable]
public class InventoryItem
{
    public string name, description;
    public InventoryItem(string n, string d) { name = n; description = d; }
}
