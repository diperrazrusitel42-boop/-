using UnityEngine;
using System.Collections;

/// <summary>
/// 3D ОСМОТР ПРЕДМЕТА
/// При нажатии E предмет "берётся в руки":
/// появляется в центре экрана, можно вращать мышью.
/// Нажать F — положить обратно.
///
/// Используется для: жетона, часов, патрона, ножа, цепочки.
/// Вешается вместе с InteractableObject.
/// </summary>
public class InspectObject3D : MonoBehaviour
{
    [Header("Настройки осмотра")]
    [SerializeField] private float inspectDistance = 0.5f;   // Расстояние от камеры
    [SerializeField] private float rotateSpeed = 200f;       // Скорость вращения
    [SerializeField] private float zoomSpeed = 0.5f;
    [SerializeField] private float smoothSpeed = 10f;        // Плавность

    [Header("Позиция")]
    [SerializeField] private Vector3 inspectOffset = new Vector3(0f, -0.1f, 0f);

    private bool isInspecting = false;
    private Vector3 originalPosition;
    private Quaternion originalRotation;
    private Transform originalParent;
    private Camera mainCamera;

    private float currentDistance;
    private Vector3 targetPosition;

    void Start()
    {
        mainCamera = Camera.main;
        currentDistance = inspectDistance;
    }

    void Update()
    {
        if (!isInspecting) return;

        // Вращение предмета мышью
        if (Input.GetMouseButton(0))
        {
            float rotX = Input.GetAxis("Mouse X") * rotateSpeed * Time.deltaTime;
            float rotY = Input.GetAxis("Mouse Y") * rotateSpeed * Time.deltaTime;
            transform.Rotate(Vector3.up, -rotX, Space.World);
            transform.Rotate(Vector3.right, rotY, Space.World);
        }

        // Зум колёсиком
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        currentDistance = Mathf.Clamp(
            currentDistance - scroll * zoomSpeed, 0.2f, 1.2f);

        // Плавное движение к позиции осмотра
        targetPosition = mainCamera.transform.position +
                         mainCamera.transform.forward * currentDistance +
                         inspectOffset;
        transform.position = Vector3.Lerp(
            transform.position, targetPosition, smoothSpeed * Time.deltaTime);

        // F — положить обратно
        if (Input.GetKeyDown(KeyCode.F))
            StopInspecting();
    }

    /// <summary>
    /// Начать осмотр предмета
    /// Вызывается из InteractableObject.OnInteract()
    /// </summary>
    public void StartInspecting()
    {
        if (isInspecting) return;

        isInspecting = true;
        originalPosition = transform.position;
        originalRotation = transform.rotation;
        originalParent = transform.parent;

        // Выносим из иерархии чтобы не двигался вместе с родителем
        transform.SetParent(null);

        // Останавливаем игрока
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);

        // Разблокируем курсор
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // Показываем подсказку
        UIManager.Instance?.ShowInteractHint("[F] Положить | Мышь — вращать | Колёсико — приближение");

        currentDistance = inspectDistance;
    }

    void StopInspecting()
    {
        isInspecting = false;

        // Возвращаем предмет на место
        StartCoroutine(ReturnToPlace());
    }

    IEnumerator ReturnToPlace()
    {
        float elapsed = 0f;
        float duration = 0.5f;

        Vector3 startPos = transform.position;
        Quaternion startRot = transform.rotation;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / duration);
            transform.position = Vector3.Lerp(startPos, originalPosition, t);
            transform.rotation = Quaternion.Slerp(startRot, originalRotation, t);
            yield return null;
        }

        transform.position = originalPosition;
        transform.rotation = originalRotation;
        transform.SetParent(originalParent);

        // Возвращаем управление
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        UIManager.Instance?.HideInteractHint();
    }
}
