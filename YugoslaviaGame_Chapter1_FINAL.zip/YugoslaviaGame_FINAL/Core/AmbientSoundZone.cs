using UnityEngine;

/// <summary>
/// ЗОНА АТМОСФЕРНОГО ЗВУКА
/// Когда игрок входит в зону — плавно включается звук.
/// Когда выходит — плавно выключается.
///
/// Использование:
/// — Звук дождя у окна
/// — Радио в кухне
/// — Гул труб в ванной
/// — Скрип ступеней в подъезде
/// — Звуки улицы у выхода
///
/// Вешается на невидимый объект с Collider (Is Trigger: ✓)
/// </summary>
public class AmbientSoundZone : MonoBehaviour
{
    [Header("Звук")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private float maxVolume = 0.5f;
    [SerializeField] private float fadeSpeed = 2f;

    [Header("Опции")]
    [SerializeField] private bool looping = true;
    [SerializeField] private bool playOnEnter = true;

    private bool playerInside = false;
    private float targetVolume = 0f;

    void Start()
    {
        if (audioSource != null)
        {
            audioSource.loop = looping;
            audioSource.volume = 0f;
            if (looping) audioSource.Play();
        }
    }

    void Update()
    {
        if (audioSource == null) return;

        // Плавное изменение громкости
        targetVolume = playerInside ? maxVolume : 0f;
        audioSource.volume = Mathf.MoveTowards(
            audioSource.volume, targetVolume, fadeSpeed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        playerInside = true;

        if (!looping && playOnEnter && audioSource != null)
            audioSource.Play();
    }

    void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        playerInside = false;
    }
}
