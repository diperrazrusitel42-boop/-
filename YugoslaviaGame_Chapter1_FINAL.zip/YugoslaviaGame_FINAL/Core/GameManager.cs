using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// ГЛАВНЫЙ МЕНЕДЖЕР ИГРЫ — единственный объект между сценами.
/// Создайте пустой объект GameManager в стартовой сцене.
/// Все остальные системы обращаются к нему через GameManager.Instance
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    // ====== ССЫЛКИ НА СИСТЕМЫ ======
    [HideInInspector] public SaveSystem     Save;
    [HideInInspector] public InventoryManager Inventory;
    [HideInInspector] public JournalSystem  Journal;

    // ====== МОРАЛЬНЫЙ СЧЁТ ======
    private int moralScore = 0;

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        Save      = GetComponent<SaveSystem>();
        Inventory = GetComponent<InventoryManager>();
        Journal   = GetComponent<JournalSystem>();

        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "MainMenu") return;
        var player = FindObjectOfType<PlayerController>();
        if (player != null) Save?.RestorePlayerPosition(player);
    }

    // ====== БЫСТРЫЕ МЕТОДЫ ======
    public void SaveGame(int slot = 1)  => Save?.SaveToSlot(slot);
    public void LoadGame(int slot = 1)  => Save?.LoadFromSlot(slot);
    public bool HasItem(string name)    => Inventory?.HasItem(name) ?? false;
    public void AddToJournal(JournalSystem.EntryID id) => Journal?.AddEntry(id);

    public void RecordMoralChoice(string choice, int value)
    {
        moralScore += value;
        Save?.RecordChoice($"{choice}:{value}");
        Debug.Log($"[Мораль] {choice}: {value:+#;-#;0} → итого {moralScore}");
    }

    public int GetMoralScore() => moralScore;

    // ====== ПРОВЕРКИ ПРОГРЕССА ======
    public bool CanOpenMailbox()     => HasItem("Ключ от ящика №17");
    public bool CanOpenMoneyHide()   => HasItem("Письмо старика к семье");
    public bool CanShoot()           => HasItem("Револьвер") && HasItem("Патроны 7.62 мм");
    public bool IsChapter1Complete() => (Save?.GetFlag("bodyFound") ?? false)
                                     && (Save?.GetFlag("mailboxOpened") ?? false);

    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
}
