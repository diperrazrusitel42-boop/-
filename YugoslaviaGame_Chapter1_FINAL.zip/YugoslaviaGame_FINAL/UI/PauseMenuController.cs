using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// МЕНЮ ПАУЗЫ (ESC во время игры)
/// Минималистичное, в духе эпохи:
/// [ПРОДОЛЖИТЬ] [СОХРАНИТЬ] [ЗАГРУЗИТЬ] [НАСТРОЙКИ] [ГЛАВНОЕ МЕНЮ]
/// </summary>
public class PauseMenuController : MonoBehaviour
{
    public static PauseMenuController Instance;

    [Header("Панели")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject savePanel;
    [SerializeField] private GameObject settingsPanel;
    [SerializeField] private GameObject confirmExitPanel;

    [Header("Кнопки паузы")]
    [SerializeField] private Button btnResume;
    [SerializeField] private Button btnSave;
    [SerializeField] private Button btnSettings;
    [SerializeField] private Button btnMainMenu;

    [Header("Слоты сохранений в паузе")]
    [SerializeField] private List<SaveSlotUI> saveSlotUIs;

    [Header("Визуал")]
    [SerializeField] private Image pauseBackground;   // Полупрозрачный фон
    [SerializeField] private Text pauseTitleText;

    [Header("Звук")]
    [SerializeField] private AudioClip openSound;
    [SerializeField] private AudioClip closeSound;
    [SerializeField] private AudioSource audioSource;

    private bool isPaused = false;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        SetupButtons();
        HidePause();
    }

    void Update()
    {
        // ESC — открыть/закрыть паузу
        if (Input.GetKeyDown(KeyCode.Escape))
            TogglePause();
    }

    void SetupButtons()
    {
        if (btnResume != null)   btnResume.onClick.AddListener(Resume);
        if (btnSave != null)     btnSave.onClick.AddListener(OpenSave);
        if (btnSettings != null) btnSettings.onClick.AddListener(OpenSettings);
        if (btnMainMenu != null) btnMainMenu.onClick.AddListener(OpenConfirmExit);
    }

    // ================================
    // ПАУЗА
    // ================================

    public void TogglePause()
    {
        if (isPaused) Resume();
        else Pause();
    }

    public void Pause()
    {
        isPaused = true;
        Time.timeScale = 0f;  // Останавливаем время

        // Разблокируем курсор
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // Останавливаем движение игрока
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);

        // Показываем паузу
        ShowPausePanel();

        if (openSound != null && audioSource != null)
            audioSource.PlayOneShot(openSound);
    }

    public void Resume()
    {
        isPaused = false;
        Time.timeScale = 1f;  // Возвращаем время

        // Блокируем курсор
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // Возвращаем движение
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);

        HidePause();

        if (closeSound != null && audioSource != null)
            audioSource.PlayOneShot(closeSound);
    }

    // ================================
    // СОХРАНЕНИЕ В ПАУЗЕ
    // ================================

    void OpenSave()
    {
        ShowPanel(savePanel);
        RefreshSaveSlots();
    }

    void RefreshSaveSlots()
    {
        if (SaveSystem.Instance == null) return;

        List<SaveSlotInfo> slots = SaveSystem.Instance.GetAllSlotsInfo();

        for (int i = 0; i < saveSlotUIs.Count && i < slots.Count; i++)
        {
            int slotIndex = i;
            saveSlotUIs[i].SetData(slots[i]);
            saveSlotUIs[i].button.onClick.RemoveAllListeners();
            saveSlotUIs[i].button.onClick.AddListener(() => {
                SaveSystem.Instance?.SaveToSlot(slotIndex);
                ShowPausePanel();
            });
        }
    }

    // ================================
    // ВЫХОД В ГЛАВНОЕ МЕНЮ
    // ================================

    void OpenConfirmExit()
    {
        ShowPanel(confirmExitPanel);
    }

    public void ConfirmExitToMenu()
    {
        Time.timeScale = 1f;
        SaveSystem.Instance?.AutoSave();  // Автосохранение перед выходом
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }

    public void CancelExit()
    {
        ShowPausePanel();
    }

    void OpenSettings()
    {
        ShowPanel(settingsPanel);
    }

    // ================================
    // ВСПОМОГАТЕЛЬНЫЕ
    // ================================

    void ShowPausePanel()
    {
        if (pausePanel != null) pausePanel.SetActive(true);
        if (savePanel != null) savePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);
        if (confirmExitPanel != null) confirmExitPanel.SetActive(false);
    }

    void ShowPanel(GameObject panel)
    {
        if (pausePanel != null) pausePanel.SetActive(false);
        if (savePanel != null) savePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);
        if (confirmExitPanel != null) confirmExitPanel.SetActive(false);
        if (panel != null) panel.SetActive(true);
    }

    void HidePause()
    {
        if (pausePanel != null) pausePanel.SetActive(false);
        if (savePanel != null) savePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);
        if (confirmExitPanel != null) confirmExitPanel.SetActive(false);
    }

    public bool IsPaused => isPaused;
}
