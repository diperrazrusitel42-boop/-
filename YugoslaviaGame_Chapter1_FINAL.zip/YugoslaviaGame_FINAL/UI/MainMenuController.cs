using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// ГЛАВНОЕ МЕНЮ
/// Стилизовано под советско-югославскую эстетику 1991 года.
/// Минимализм, кириллица, зернистость.
///
/// Структура меню:
/// [НОВАЯ ИГРА] → выбор слота → начало
/// [ПРОДОЛЖИТЬ] → выбор слота → загрузка
/// [НАСТРОЙКИ]  → звук, графика
/// [ВЫХОД]      → подтверждение
/// </summary>
public class MainMenuController : MonoBehaviour
{
    // ================================
    // ПАНЕЛИ МЕНЮ
    // ================================
    [Header("Панели")]
    [SerializeField] private GameObject panelMain;        // Главное меню
    [SerializeField] private GameObject panelNewGame;     // Выбор слота (новая игра)
    [SerializeField] private GameObject panelLoad;        // Выбор слота (загрузка)
    [SerializeField] private GameObject panelSettings;    // Настройки
    [SerializeField] private GameObject panelConfirmExit; // Подтверждение выхода
    [SerializeField] private GameObject panelCredits;     // О проекте

    // ================================
    // ЗАГОЛОВОК
    // ================================
    [Header("Заголовок")]
    [SerializeField] private Text gameTitleText;       // Название игры
    [SerializeField] private Text subtitleText;        // Подзаголовок
    [SerializeField] private Text dateText;            // "Октябрь 1991"
    [SerializeField] private Image backgroundImage;    // Фоновое изображение

    // ================================
    // КНОПКИ ГЛАВНОГО МЕНЮ
    // ================================
    [Header("Кнопки главного меню")]
    [SerializeField] private Button btnNewGame;
    [SerializeField] private Button btnContinue;
    [SerializeField] private Button btnSettings;
    [SerializeField] private Button btnCredits;
    [SerializeField] private Button btnExit;

    // ================================
    // СЛОТЫ СОХРАНЕНИЙ
    // ================================
    [Header("Слоты сохранений")]
    [SerializeField] private List<SaveSlotUI> saveSlotUIs;  // 3 слота в UI

    // ================================
    // НАСТРОЙКИ
    // ================================
    [Header("Настройки")]
    [SerializeField] private Slider sliderMaster;     // Общая громкость
    [SerializeField] private Slider sliderMusic;      // Музыка
    [SerializeField] private Slider sliderEffects;    // Эффекты
    [SerializeField] private Slider sliderSensitivity;// Чувствительность мыши
    [SerializeField] private Toggle toggleSubtitles;  // Субтитры
    [SerializeField] private Toggle toggleGrain;      // Зернистость экрана

    // ================================
    // АТМОСФЕРА
    // ================================
    [Header("Атмосфера меню")]
    [SerializeField] private AudioSource menuMusic;      // Фоновая музыка меню
    [SerializeField] private AudioSource rainSound;      // Звук дождя
    [SerializeField] private AudioClip buttonClickSound; // Клик кнопки
    [SerializeField] private AudioSource uiAudio;

    private bool isNewGameMode = false;  // Режим: новая игра или загрузка

    void Start()
    {
        SetupButtons();
        ShowPanel(panelMain);
        LoadSettings();
        StartCoroutine(AnimateTitle());

        // Запускаем атмосферный звук
        if (menuMusic != null) menuMusic.Play();
        if (rainSound != null) rainSound.Play();

        // Разблокируем курсор в меню
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    // ================================
    // НАСТРОЙКА КНОПОК
    // ================================
    void SetupButtons()
    {
        if (btnNewGame != null)  btnNewGame.onClick.AddListener(OnNewGame);
        if (btnContinue != null) btnContinue.onClick.AddListener(OnContinue);
        if (btnSettings != null) btnSettings.onClick.AddListener(OnSettings);
        if (btnCredits != null)  btnCredits.onClick.AddListener(OnCredits);
        if (btnExit != null)     btnExit.onClick.AddListener(OnExit);

        // Кнопку "Продолжить" показываем только если есть сохранения
        bool hasSaves = CheckHasSaves();
        if (btnContinue != null)
            btnContinue.interactable = hasSaves;
    }

    bool CheckHasSaves()
    {
        if (SaveSystem.Instance == null) return false;
        var slots = SaveSystem.Instance.GetAllSlotsInfo();
        foreach (var slot in slots)
            if (!slot.isEmpty) return true;
        return false;
    }

    // ================================
    // ОБРАБОТЧИКИ КНОПОК
    // ================================

    void OnNewGame()
    {
        PlayClick();
        isNewGameMode = true;
        ShowPanel(panelNewGame);
        RefreshSaveSlots();
    }

    void OnContinue()
    {
        PlayClick();
        isNewGameMode = false;
        ShowPanel(panelLoad);
        RefreshSaveSlots();
    }

    void OnSettings()
    {
        PlayClick();
        ShowPanel(panelSettings);
    }

    void OnCredits()
    {
        PlayClick();
        ShowPanel(panelCredits);
    }

    void OnExit()
    {
        PlayClick();
        ShowPanel(panelConfirmExit);
    }

    public void OnExitConfirmed()
    {
        Application.Quit();
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }

    public void OnExitCancelled()
    {
        PlayClick();
        ShowPanel(panelMain);
    }

    public void OnBackToMain()
    {
        PlayClick();
        ShowPanel(panelMain);
    }

    // ================================
    // СЛОТЫ СОХРАНЕНИЙ
    // ================================

    void RefreshSaveSlots()
    {
        if (SaveSystem.Instance == null) return;

        List<SaveSlotInfo> slots = SaveSystem.Instance.GetAllSlotsInfo();

        for (int i = 0; i < saveSlotUIs.Count && i < slots.Count; i++)
        {
            int slotIndex = i; // Захватываем для лямбды
            SaveSlotInfo info = slots[i];
            SaveSlotUI ui = saveSlotUIs[i];

            ui.SetData(info);

            // Очищаем старые события
            ui.button.onClick.RemoveAllListeners();

            if (isNewGameMode)
            {
                // Новая игра — клик начинает новую игру в этом слоте
                ui.button.onClick.AddListener(() => StartNewGameInSlot(slotIndex));
            }
            else
            {
                // Загрузка — клик загружает слот (если не пуст)
                if (!info.isEmpty)
                    ui.button.onClick.AddListener(() => LoadSlot(slotIndex));
                else
                    ui.button.interactable = false;
            }
        }
    }

    void StartNewGameInSlot(int slot)
    {
        PlayClick();
        // Если слот занят — предупреждение (можно добавить)
        StartCoroutine(FadeAndLoad(() => SaveSystem.Instance?.StartNewGame(slot)));
    }

    void LoadSlot(int slot)
    {
        PlayClick();
        StartCoroutine(FadeAndLoad(() => SaveSystem.Instance?.LoadFromSlot(slot)));
    }

    // ================================
    // НАСТРОЙКИ
    // ================================

    void LoadSettings()
    {
        if (sliderMaster != null)
            sliderMaster.value = PlayerPrefs.GetFloat("MasterVolume", 1f);

        if (sliderMusic != null)
            sliderMusic.value = PlayerPrefs.GetFloat("MusicVolume", 0.7f);

        if (sliderEffects != null)
            sliderEffects.value = PlayerPrefs.GetFloat("EffectsVolume", 1f);

        if (sliderSensitivity != null)
            sliderSensitivity.value = PlayerPrefs.GetFloat("MouseSensitivity", 2f);

        if (toggleSubtitles != null)
            toggleSubtitles.isOn = PlayerPrefs.GetInt("Subtitles", 1) == 1;

        if (toggleGrain != null)
            toggleGrain.isOn = PlayerPrefs.GetInt("FilmGrain", 1) == 1;

        // Вешаем обработчики
        sliderMaster?.onValueChanged.AddListener(v => {
            PlayerPrefs.SetFloat("MasterVolume", v);
            AudioListener.volume = v;
        });

        sliderSensitivity?.onValueChanged.AddListener(v => {
            PlayerPrefs.SetFloat("MouseSensitivity", v);
        });

        toggleSubtitles?.onValueChanged.AddListener(v => {
            PlayerPrefs.SetInt("Subtitles", v ? 1 : 0);
        });
    }

    public void SaveSettings()
    {
        PlayerPrefs.Save();
        PlayClick();
        ShowPanel(panelMain);
    }

    // ================================
    // ВСПОМОГАТЕЛЬНЫЕ
    // ================================

    void ShowPanel(GameObject panel)
    {
        // Скрываем все панели
        panelMain?.SetActive(false);
        panelNewGame?.SetActive(false);
        panelLoad?.SetActive(false);
        panelSettings?.SetActive(false);
        panelConfirmExit?.SetActive(false);
        panelCredits?.SetActive(false);

        // Показываем нужную
        panel?.SetActive(true);
    }

    void PlayClick()
    {
        if (buttonClickSound != null && uiAudio != null)
            uiAudio.PlayOneShot(buttonClickSound);
    }

    IEnumerator FadeAndLoad(System.Action loadAction)
    {
        // Плавное затемнение перед загрузкой
        // BlackScreen должен быть в сцене меню
        BlackScreenController black = FindObjectOfType<BlackScreenController>();
        if (black != null)
            yield return StartCoroutine(black.FadeIn(1f));

        yield return new WaitForSeconds(0.5f);
        loadAction?.Invoke();
    }

    IEnumerator AnimateTitle()
    {
        // Мигающий эффект для подзаголовка (как на советских экранах)
        while (true)
        {
            yield return new WaitForSeconds(3f);
            if (subtitleText != null)
            {
                subtitleText.enabled = false;
                yield return new WaitForSeconds(0.1f);
                subtitleText.enabled = true;
            }
        }
    }
}

/// <summary>
/// UI одного слота сохранения
/// Вешается на каждый объект-слот в меню
/// </summary>
[System.Serializable]
public class SaveSlotUI
{
    public Button button;
    public Text slotNameText;
    public Text dateTimeText;
    public Text chapterText;
    public Text playTimeText;
    public GameObject emptyLabel;     // "Пусто"
    public GameObject occupiedGroup;  // Контейнер с данными

    public void SetData(SaveSlotInfo info)
    {
        if (info.isEmpty)
        {
            if (emptyLabel != null) emptyLabel.SetActive(true);
            if (occupiedGroup != null) occupiedGroup.SetActive(false);
            if (slotNameText != null) slotNameText.text = info.slotName;
        }
        else
        {
            if (emptyLabel != null) emptyLabel.SetActive(false);
            if (occupiedGroup != null) occupiedGroup.SetActive(true);
            if (slotNameText != null)  slotNameText.text = info.slotName;
            if (dateTimeText != null)  dateTimeText.text = info.dateTime;
            if (chapterText != null)   chapterText.text = info.chapterName;
            if (playTimeText != null)  playTimeText.text = $"Время: {info.playTime}";
        }
    }
}
