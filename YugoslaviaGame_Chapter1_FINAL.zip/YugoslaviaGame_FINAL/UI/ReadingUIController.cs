using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// UI ДЛЯ ЧТЕНИЯ ДОКУМЕНТОВ
/// Открывает полноэкранный режим чтения газет, писем, записок.
/// Стилизовано под советско-югославский документ 1991 года.
///
/// Вешается на объект ReadingUI в Canvas.
/// </summary>
public class ReadingUIController : MonoBehaviour
{
    public static ReadingUIController Instance;

    [Header("Панель чтения")]
    [SerializeField] private GameObject readingPanel;
    [SerializeField] private Text titleText;
    [SerializeField] private Text contentText;
    [SerializeField] private Image documentBackground;   // Фон: бумага газеты или письма
    [SerializeField] private Image documentPhoto;        // Опциональное фото документа

    [Header("Текстуры фона документов")]
    [SerializeField] private Sprite newspaperBackground;   // Текстура газеты
    [SerializeField] private Sprite letterBackground;      // Текстура письма (рукопись)
    [SerializeField] private Sprite officialBackground;    // Официальный бланк

    [Header("Шрифты")]
    [SerializeField] private Font printedFont;      // Печатный шрифт
    [SerializeField] private Font handwrittenFont;  // Рукописный шрифт

    [Header("Подсказка закрытия")]
    [SerializeField] private Text closeHintText;
    [SerializeField] private string closeHint = "[F] или [Пробел] — закрыть";

    private bool isOpen = false;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        if (readingPanel != null)
            readingPanel.SetActive(false);

        if (closeHintText != null)
            closeHintText.text = closeHint;
    }

    void Update()
    {
        // Закрыть документ по F или Пробел
        if (isOpen && (Input.GetKeyDown(KeyCode.F) || Input.GetKeyDown(KeyCode.Space)))
        {
            CloseDocument();
        }
    }

    /// <summary>
    /// Открыть документ на экране
    /// </summary>
    public void ShowDocument(string title, string content, Sprite photo, bool isHandwritten)
    {
        if (readingPanel == null) return;

        // Заполняем данные
        if (titleText != null)    titleText.text = title;
        if (contentText != null)  contentText.text = content;

        // Устанавливаем фото если есть
        if (documentPhoto != null)
        {
            documentPhoto.sprite = photo;
            documentPhoto.gameObject.SetActive(photo != null);
        }

        // Стиль: рукописный или печатный
        if (contentText != null)
        {
            if (isHandwritten && handwrittenFont != null)
                contentText.font = handwrittenFont;
            else if (!isHandwritten && printedFont != null)
                contentText.font = printedFont;
        }

        // Выбираем фон
        if (documentBackground != null)
        {
            if (isHandwritten && letterBackground != null)
                documentBackground.sprite = letterBackground;
            else if (newspaperBackground != null)
                documentBackground.sprite = newspaperBackground;
        }

        // Показываем панель
        readingPanel.SetActive(true);
        isOpen = true;

        // Останавливаем игрока пока читает
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(false);
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    /// <summary>
    /// Закрыть документ
    /// </summary>
    public void CloseDocument()
    {
        if (readingPanel != null)
            readingPanel.SetActive(false);

        isOpen = false;

        // Возвращаем управление
        FindObjectOfType<PlayerController>()?.SetMovementEnabled(true);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
}
