using UnityEngine;
using UnityEngine.UI;
using System;

/// <summary>
/// СИСТЕМА МОРАЛЬНОГО ВЫБОРА
/// Появляется когда игрок должен принять решение.
/// Первый выбор: стрелять в тень или нет.
///
/// Стиль: минималистичный, без лишних украшений.
/// Два текстовых варианта снизу экрана.
/// </summary>
public class ChoiceUIManager : MonoBehaviour
{
    public static ChoiceUIManager Instance;

    [Header("Панель выбора")]
    [SerializeField] private GameObject choicePanel;
    [SerializeField] private Text situationText;      // Описание ситуации
    [SerializeField] private Button choiceButton1;    // Левая кнопка
    [SerializeField] private Button choiceButton2;    // Правая кнопка
    [SerializeField] private Text choiceText1;        // Текст левой кнопки
    [SerializeField] private Text choiceText2;        // Текст правой кнопки

    private Action onChoice1;
    private Action onChoice2;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        if (choicePanel != null)
            choicePanel.SetActive(false);

        // Привязываем кнопки
        if (choiceButton1 != null)
            choiceButton1.onClick.AddListener(OnButton1Clicked);

        if (choiceButton2 != null)
            choiceButton2.onClick.AddListener(OnButton2Clicked);
    }

    /// <summary>
    /// Показать выбор игроку
    /// </summary>
    public void ShowChoice(string situation, ChoiceOption option1, ChoiceOption option2)
    {
        if (choicePanel == null) return;

        // Заполняем текст
        if (situationText != null)  situationText.text = situation;
        if (choiceText1 != null)    choiceText1.text = option1.text;
        if (choiceText2 != null)    choiceText2.text = option2.text;

        // Сохраняем колбэки
        onChoice1 = option1.onSelected;
        onChoice2 = option2.onSelected;

        // Показываем панель
        choicePanel.SetActive(true);

        // Разблокируем курсор для кликов
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void OnButton1Clicked()
    {
        CloseChoice();
        onChoice1?.Invoke();
    }

    void OnButton2Clicked()
    {
        CloseChoice();
        onChoice2?.Invoke();
    }

    void CloseChoice()
    {
        if (choicePanel != null)
            choicePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
}

/// <summary>
/// Вариант выбора: текст + что происходит при выборе
/// </summary>
[System.Serializable]
public class ChoiceOption
{
    public string text;
    public Action onSelected;

    public ChoiceOption(string text, Action onSelected)
    {
        this.text = text;
        this.onSelected = onSelected;
    }
}
