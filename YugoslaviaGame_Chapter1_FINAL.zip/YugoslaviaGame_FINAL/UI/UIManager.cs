using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// UI МЕНЕДЖЕР — ФИНАЛЬНАЯ ВЕРСИЯ
/// Единая точка управления всем интерфейсом.
/// Вешается на объект UIManager в Canvas.
///
/// Панели в Canvas (создайте все):
/// - InteractHintPanel   → подсказка [E] внизу по центру
/// - MonologuePanel      → монолог героя внизу
/// - InspectPanel        → описание предмета (имя + текст)
/// - NPCDialoguePanel    → реплика NPC слева
/// - RadioPanel          → субтитры радио вверху
/// - NotificationPanel   → мгновенные уведомления (инвентарь)
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    // ── ПОДСКАЗКА ВЗАИМОДЕЙСТВИЯ ──────────────────────────────
    [Header("Подсказка [E]")]
    [SerializeField] private GameObject interactHintPanel;
    [SerializeField] private Text interactHintText;

    // ── МОНОЛОГ ГЕРОЯ ────────────────────────────────────────
    [Header("Монолог героя")]
    [SerializeField] private GameObject monologuePanel;
    [SerializeField] private Text monologueText;
    [SerializeField] private float typingSpeed   = 0.025f; // сек на символ
    [SerializeField] private float holdTime      = 5f;     // сколько держать после печати

    // ── ОСМОТР ПРЕДМЕТА ──────────────────────────────────────
    [Header("Осмотр предмета")]
    [SerializeField] private GameObject inspectPanel;
    [SerializeField] private Text inspectNameText;
    [SerializeField] private Text inspectDescText;

    // ── ДИАЛОГ NPC ───────────────────────────────────────────
    [Header("Диалог NPC")]
    [SerializeField] private GameObject npcPanel;
    [SerializeField] private Text npcNameText;
    [SerializeField] private Text npcPhraseText;
    [SerializeField] private float npcHoldTime = 5f;

    // ── РАДИО ────────────────────────────────────────────────
    [Header("Радио (субтитры)")]
    [SerializeField] private GameObject radioPanel;
    [SerializeField] private Text radioText;
    [SerializeField] private float radioHoldTime = 9f;

    // ── УВЕДОМЛЕНИЕ ──────────────────────────────────────────
    [Header("Уведомление")]
    [SerializeField] private GameObject notifPanel;
    [SerializeField] private Text notifText;
    [SerializeField] private float notifHoldTime = 3f;

    // ── ВНУТРЕННЕЕ ───────────────────────────────────────────
    private Coroutine _monologueRoutine;
    private string    _pendingMonologue; // текст который сейчас печатается

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
    }

    void Start() => HideAll();

    // ════════════════════════════════════════════════════════
    // ПОДСКАЗКА
    // ════════════════════════════════════════════════════════
    public void ShowInteractHint(string text)
    {
        interactHintPanel?.SetActive(true);
        if (interactHintText) interactHintText.text = $"[E]  {text}";
    }

    public void HideInteractHint() => interactHintPanel?.SetActive(false);

    // ════════════════════════════════════════════════════════
    // ОСМОТР ПРЕДМЕТА
    // ════════════════════════════════════════════════════════
    public void ShowObjectInfo(string name, string desc, string monologue)
    {
        if (inspectPanel)
        {
            inspectPanel.SetActive(true);
            if (inspectNameText) inspectNameText.text = name;
            if (inspectDescText) inspectDescText.text = desc;
        }
        if (!string.IsNullOrEmpty(monologue)) ShowMonologue(monologue);
    }

    public void HideObjectInfo() => inspectPanel?.SetActive(false);

    // ════════════════════════════════════════════════════════
    // МОНОЛОГ (с эффектом печатания, пауза на знаках)
    // ════════════════════════════════════════════════════════
    public void ShowMonologue(string text)
    {
        if (!monologuePanel) return;
        if (_monologueRoutine != null) StopCoroutine(_monologueRoutine);
        _pendingMonologue = text;
        _monologueRoutine = StartCoroutine(MonologueRoutine(text));
    }

    IEnumerator MonologueRoutine(string text)
    {
        monologuePanel.SetActive(true);
        if (monologueText) monologueText.text = "";

        foreach (char c in text)
        {
            if (monologueText) monologueText.text += c;

            // Пауза на знаках препинания — создаёт ритм речи
            float pause = c switch
            {
                '.' or '!' or '?' => typingSpeed * 10f,
                ',' or ';'        => typingSpeed * 5f,
                '\n'              => typingSpeed * 6f,
                '—'               => typingSpeed * 3f,
                _                 => typingSpeed
            };
            yield return new WaitForSeconds(pause);
        }

        yield return new WaitForSeconds(holdTime);
        monologuePanel.SetActive(false);
        HideObjectInfo();
    }

    // Нажатие Пробел — пропустить анимацию, показать сразу весь текст
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)
            && monologuePanel != null && monologuePanel.activeSelf)
        {
            if (_monologueRoutine != null) StopCoroutine(_monologueRoutine);
            if (monologueText && _pendingMonologue != null)
                monologueText.text = _pendingMonologue;
            _monologueRoutine = StartCoroutine(HoldThenHide());
        }
    }

    IEnumerator HoldThenHide()
    {
        yield return new WaitForSeconds(holdTime);
        monologuePanel?.SetActive(false);
        HideObjectInfo();
    }

    // ════════════════════════════════════════════════════════
    // ДИАЛОГ NPC
    // ════════════════════════════════════════════════════════
    public void ShowNPCDialogue(string name, string phrase)
    {
        if (!npcPanel) return;
        npcPanel.SetActive(true);
        if (npcNameText)   npcNameText.text   = name;
        if (npcPhraseText) npcPhraseText.text = $"«{phrase}»";
        CancelInvoke(nameof(HideNPC));
        Invoke(nameof(HideNPC), npcHoldTime);
    }
    void HideNPC() => npcPanel?.SetActive(false);

    // ════════════════════════════════════════════════════════
    // РАДИО
    // ════════════════════════════════════════════════════════
    public void ShowRadioSubtitle(string text)
    {
        if (!radioPanel) return;
        radioPanel.SetActive(true);
        if (radioText) radioText.text = $"◈ Радио:  {text}";
        CancelInvoke(nameof(HideRadio));
        Invoke(nameof(HideRadio), radioHoldTime);
    }
    void HideRadio() => radioPanel?.SetActive(false);

    // ════════════════════════════════════════════════════════
    // УВЕДОМЛЕНИЕ
    // ════════════════════════════════════════════════════════
    public void ShowNotification(string text)
    {
        if (!notifPanel) return;
        notifPanel.SetActive(true);
        if (notifText) notifText.text = text;
        CancelInvoke(nameof(HideNotif));
        Invoke(nameof(HideNotif), notifHoldTime);
    }
    void HideNotif() => notifPanel?.SetActive(false);

    // ════════════════════════════════════════════════════════
    // ВСПОМОГАТЕЛЬНЫЕ
    // ════════════════════════════════════════════════════════
    void HideAll()
    {
        interactHintPanel?.SetActive(false);
        monologuePanel?.SetActive(false);
        inspectPanel?.SetActive(false);
        npcPanel?.SetActive(false);
        radioPanel?.SetActive(false);
        notifPanel?.SetActive(false);
    }
}
