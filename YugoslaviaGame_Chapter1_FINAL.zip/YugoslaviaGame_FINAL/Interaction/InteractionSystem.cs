using UnityEngine;

/// <summary>
/// СИСТЕМА ВЗАИМОДЕЙСТВИЯ — ФИНАЛЬНАЯ ВЕРСИЯ
/// Вешается на ИГРОКА.
///
/// Обрабатывает ВСЕ типы объектов одним лучом:
/// - InteractableObject  → предметы, документы, 3D осмотр
/// - DoorInteraction     → двери
/// - AtmosphericNPC      → NPC с репликами
/// - HiddenObject        → тайники
/// - BodyInspector       → осмотр тела
/// - MailboxEvent        → почтовый ящик
/// </summary>
public class InteractionSystem : MonoBehaviour
{
    [Header("Настройки луча")]
    [SerializeField] private float interactRange  = 2.5f;
    [SerializeField] private LayerMask interactableLayer = ~0; // Все слои по умолчанию
    [SerializeField] private Camera playerCamera;

    [Header("Отладка")]
    [SerializeField] private bool showDebugRay = false;

    // Текущая цель
    private GameObject _currentTarget;

    void Start()
    {
        if (!playerCamera) playerCamera = GetComponentInChildren<Camera>();
    }

    void Update()
    {
        // Не обрабатываем взаимодействие на паузе или в меню чтения
        if (PauseMenuController.Instance != null
            && PauseMenuController.Instance.IsPaused) return;

        ScanForTarget();

        if (Input.GetKeyDown(KeyCode.E) && _currentTarget != null)
            TriggerInteract(_currentTarget);
    }

    // ─────────────────────────────────────────────────────────
    // СКАНИРОВАНИЕ
    // ─────────────────────────────────────────────────────────
    void ScanForTarget()
    {
        Ray ray = new Ray(
            playerCamera.transform.position,
            playerCamera.transform.forward);

        if (showDebugRay)
            Debug.DrawRay(ray.origin, ray.direction * interactRange, Color.yellow);

        if (Physics.Raycast(ray, out RaycastHit hit, interactRange, interactableLayer))
        {
            GameObject obj = hit.collider.gameObject;

            if (obj != _currentTarget)
            {
                // Убираем подсветку со старого
                ClearHover(_currentTarget);
                // Наводим на новый
                _currentTarget = obj;
                TriggerHover(obj);
            }
        }
        else
        {
            ClearHover(_currentTarget);
            _currentTarget = null;
        }
    }

    // ─────────────────────────────────────────────────────────
    // НАВЕДЕНИЕ
    // ─────────────────────────────────────────────────────────
    void TriggerHover(GameObject obj)
    {
        // Пробуем все возможные типы компонентов
        obj.GetComponent<InteractableObject>()?.OnHover();
        obj.GetComponent<DoorInteraction>()?.OnHover();
        obj.GetComponent<AtmosphericNPC>()?.OnHover();
        obj.GetComponent<HiddenObject>()?.OnHover();
        obj.GetComponent<BodyInspector>()?.OnHover();
        obj.GetComponent<MailboxEvent>()?.OnHover();
    }

    void ClearHover(GameObject obj)
    {
        if (obj == null) return;
        obj.GetComponent<InteractableObject>()?.OnHoverExit();
        obj.GetComponent<DoorInteraction>()?.OnHoverExit();
        obj.GetComponent<AtmosphericNPC>()?.OnHoverExit();
        obj.GetComponent<HiddenObject>()?.OnHoverExit();
        obj.GetComponent<BodyInspector>()?.OnHoverExit();
        obj.GetComponent<MailboxEvent>()?.OnHoverExit();
        UIManager.Instance?.HideInteractHint();
    }

    // ─────────────────────────────────────────────────────────
    // ВЗАИМОДЕЙСТВИЕ
    // ─────────────────────────────────────────────────────────
    void TriggerInteract(GameObject obj)
    {
        bool handled = false;

        var interactable = obj.GetComponent<InteractableObject>();
        if (interactable != null) { interactable.OnInteract(); handled = true; }

        var door = obj.GetComponent<DoorInteraction>();
        if (door != null) { door.OnInteract(); handled = true; }

        var npc = obj.GetComponent<AtmosphericNPC>();
        if (npc != null) { npc.OnInteract(); handled = true; }

        var hidden = obj.GetComponent<HiddenObject>();
        if (hidden != null) { hidden.OnInteract(); handled = true; }

        var body = obj.GetComponent<BodyInspector>();
        if (body != null) { body.OnInteract(); handled = true; }

        var mailbox = obj.GetComponent<MailboxEvent>();
        if (mailbox != null) { mailbox.OnInteract(); handled = true; }

        if (!handled)
            Debug.Log($"[Interaction] Объект не имеет компонента взаимодействия: {obj.name}");
    }
}
