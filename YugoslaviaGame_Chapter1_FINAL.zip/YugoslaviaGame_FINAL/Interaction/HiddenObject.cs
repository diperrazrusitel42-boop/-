using UnityEngine;

/// <summary>
/// СИСТЕМА ТАЙНИКОВ
/// Вешается на скрытые предметы — те, что требуют особого действия:
/// - Пощупать за шкафом
/// - Оторвать плинтус
/// - Заглянуть под стельку ботинка
/// - Нащупать под матрасом
///
/// Тайник становится видимым только после того как игрок
/// выполнил нужное действие на родительском объекте.
/// </summary>
public class HiddenObject : MonoBehaviour
{
    [Header("Настройки тайника")]
    [SerializeField] private string hiddenActionPrompt = "[E] Пощупать за шкафом";
    [SerializeField] private string discoverText = "Вы нашли кое-что спрятанное...";

    [Header("Предмет внутри тайника")]
    [SerializeField] private InteractableObject hiddenItem;  // Что спрятано

    [Header("Звук обнаружения")]
    [SerializeField] private AudioClip discoverSound;

    private bool isDiscovered = false;
    private AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();

        // Скрытый предмет изначально недоступен для взаимодействия
        if (hiddenItem != null)
            hiddenItem.gameObject.SetActive(false);
    }

    /// <summary>
    /// Вызывается когда игрок наводится на место тайника
    /// </summary>
    public void OnHover()
    {
        if (!isDiscovered)
            UIManager.Instance?.ShowInteractHint(hiddenActionPrompt);
    }

    /// <summary>
    /// Вызывается когда игрок нажимает E на месте тайника
    /// </summary>
    public void OnInteract()
    {
        if (isDiscovered) return;

        isDiscovered = true;

        // Звук обнаружения
        if (discoverSound != null && audioSource != null)
            audioSource.PlayOneShot(discoverSound);

        // Показываем монолог
        UIManager.Instance?.ShowMonologue(discoverText);

        // Активируем скрытый предмет
        if (hiddenItem != null)
        {
            hiddenItem.gameObject.SetActive(true);
            // Небольшая задержка перед возможностью взять предмет
            Invoke(nameof(EnableHiddenItem), 1.5f);
        }
    }

    void EnableHiddenItem()
    {
        // Теперь игрок может полноценно взаимодействовать с предметом
        Debug.Log($"[Тайник] Предмет доступен: {hiddenItem?.objectName}");
    }
}
