using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// ЧИТАЕМЫЕ ПРЕДМЕТЫ
/// Для газет, писем, записок, блокнотов — всего что можно "прочитать"
/// При взаимодействии открывается отдельный экран с текстом документа
///
/// Вешается вместе с InteractableObject на один объект.
/// canRead должно быть включено в InteractableObject.
/// </summary>
public class ReadableObject : MonoBehaviour
{
    [Header("Содержимое документа")]
    [SerializeField] private string documentTitle = "Газета";

    [TextArea(5, 30)]
    [SerializeField] private string documentContent = "Текст документа...";

    [Header("Вид документа")]
    [SerializeField] private Sprite documentTexture;  // Фото документа (опционально)
    [SerializeField] private bool isHandwritten = false;  // Рукописный или печатный

    [Header("Ссылка на UI менеджер чтения")]
    [SerializeField] private ReadingUIController readingUI;

    /// <summary>
    /// Открыть документ для чтения
    /// Вызывается из InteractableObject.OnInteract() если canRead = true
    /// </summary>
    public void OpenDocument()
    {
        if (readingUI == null)
            readingUI = FindObjectOfType<ReadingUIController>();

        if (readingUI != null)
            readingUI.ShowDocument(documentTitle, documentContent, documentTexture, isHandwritten);
    }
}
