using UnityEngine;

/// <summary>
/// БАЗОВЫЙ КОМПОНЕНТ КАЖДОГО ПРЕДМЕТА В ИГРЕ
/// Вешается на любой объект который игрок может осмотреть/взять/прочитать.
///
/// РЕЖИМЫ (выберите в Inspector):
/// - Просто осмотр       → заполните name/description/monologue
/// - Взять в инвентарь   → canPickUp = true
/// - Читаемый документ   → canRead = true + добавьте ReadableObject
/// - 3D осмотр в руках   → canInspect3D = true + добавьте InspectObject3D
/// - Запись в дневник    → journalEntryOnPickup (выберите ID)
/// - Сохранить флаг      → flagOnInteract = "имяФлага"
/// </summary>
public class InteractableObject : MonoBehaviour
{
    // ── ТЕКСТОВЫЕ ДАННЫЕ (заполняете вы как сценарист) ───────
    [Header("Текст — заполняете в Inspector")]
    public string objectName      = "Предмет";

    [TextArea(2, 6)]
    public string description     = "Описание предмета";

    [TextArea(2, 8)]
    public string innerMonologue  = "Внутренний монолог героя";

    // ── ПОВЕДЕНИЕ ─────────────────────────────────────────────
    [Header("Поведение")]
    public bool canPickUp       = false; // Добавить в инвентарь
    public bool canRead         = false; // Открыть режим чтения
    public bool canInspect3D    = false; // Взять в руки и крутить
    public bool oneTimeOnly     = true;  // Взаимодействие только один раз

    // ── ДОПОЛНИТЕЛЬНО ────────────────────────────────────────
    [Header("Дополнительно")]
    [SerializeField] private string flagOnInteract   = ""; // Сохранить флаг в SaveSystem
    [SerializeField] private string notificationText = ""; // Всплывающее уведомление

    [Header("Дневник")]
    [SerializeField] private bool addToJournal = false;
    [SerializeField] private JournalSystem.EntryID journalEntry;

    [Header("Звук")]
    [SerializeField] private AudioClip interactSound;

    // ── ВНУТРЕННЕЕ ───────────────────────────────────────────
    private bool _interacted = false;
    private AudioSource _audio;

    // Дочерние компоненты
    private ReadableObject  _readable;
    private InspectObject3D _inspect3D;

    void Start()
    {
        _audio     = GetComponent<AudioSource>();
        _readable  = GetComponent<ReadableObject>();
        _inspect3D = GetComponent<InspectObject3D>();
    }

    // ─────────────────────────────────────────────────────────
    // ВЫЗЫВАЕТСЯ ИЗ InteractionSystem (игрок нажал E)
    // ─────────────────────────────────────────────────────────
    public void OnInteract()
    {
        if (oneTimeOnly && _interacted) return;
        _interacted = true;

        // Звук
        if (interactSound && _audio) _audio.PlayOneShot(interactSound);

        // Показываем описание + монолог в UI
        UIManager.Instance?.ShowObjectInfo(objectName, description, innerMonologue);

        // Читаемый документ
        if (canRead && _readable != null)
            _readable.OpenDocument();

        // 3D осмотр в руках
        else if (canInspect3D && _inspect3D != null)
            _inspect3D.StartInspecting();

        // Добавить в инвентарь
        if (canPickUp)
            GameManager.Instance?.Inventory.AddItem(objectName, description);

        // Запись в дневник
        if (addToJournal)
            GameManager.Instance?.AddToJournal(journalEntry);

        // Флаг прогресса
        if (!string.IsNullOrEmpty(flagOnInteract))
            GameManager.Instance?.Save.SetFlag(flagOnInteract, true);

        // Уведомление
        if (!string.IsNullOrEmpty(notificationText))
            UIManager.Instance?.ShowNotification(notificationText);

        // Запоминаем в сохранении
        GameManager.Instance?.Save.MarkObjectInspected(objectName);
    }

    // ─────────────────────────────────────────────────────────
    // ВЫЗЫВАЕТСЯ ИЗ InteractionSystem (навёл курсор)
    // ─────────────────────────────────────────────────────────
    public void OnHover()
    {
        // Подсказка зависит от типа предмета
        string hint = canRead       ? $"Прочитать: {objectName}"
                    : canPickUp     ? $"Взять: {objectName}"
                    : canInspect3D  ? $"Осмотреть: {objectName}"
                    :                  objectName;

        UIManager.Instance?.ShowInteractHint(hint);
    }

    public void OnHoverExit() => UIManager.Instance?.HideInteractHint();

    // ─────────────────────────────────────────────────────────
    // Сбросить состояние (для повторного взаимодействия)
    // ─────────────────────────────────────────────────────────
    public void ResetInteraction() => _interacted = false;
}
