using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// ОСМОТР ТЕЛА
/// Специальная система для сцены с телом старика (Сцена 8).
/// Осмотр идёт поэтапно: сначала общий вид,
/// потом отдельные части (лицо, карманы, ботинки).
/// Каждый этап разблокируется после предыдущего.
/// </summary>
public class BodyInspector : MonoBehaviour
{
    [Header("Этапы осмотра")]
    [SerializeField] private List<BodyInspectStage> stages;

    [Header("Итоговый монолог (после полного осмотра)")]
    [TextArea(3, 10)]
    [SerializeField] private string conclusionMonologue =
        "Я стоял над ним и смотрел. Держу в руках его тайны.";

    private int currentStage = 0;
    private bool inspectionComplete = false;

    void Start()
    {
        // Активируем только первый этап
        UpdateStageVisibility();
    }

    /// <summary>
    /// Вызывается при взаимодействии с телом
    /// </summary>
    public void OnInteract()
    {
        if (inspectionComplete) return;

        if (currentStage < stages.Count)
        {
            var stage = stages[currentStage];

            // Показываем монолог этапа
            UIManager.Instance?.ShowMonologue(stage.stageMonologue);

            // Если у этапа есть предмет для получения
            if (stage.itemToReveal != null)
            {
                stage.itemToReveal.SetActive(true);
                if (stage.itemName != "")
                    InventoryManager.Instance?.AddItem(stage.itemName, stage.itemDescription);
            }

            currentStage++;
            UpdateStageVisibility();

            // Проверяем завершение
            if (currentStage >= stages.Count)
            {
                inspectionComplete = true;
                Invoke(nameof(ShowConclusion), 3f);
            }
        }
    }

    void UpdateStageVisibility()
    {
        // Обновляем подсказку для текущего этапа
        if (currentStage < stages.Count)
        {
            var stage = stages[currentStage];
            UIManager.Instance?.ShowInteractHint(stage.actionPrompt);
        }
    }

    void ShowConclusion()
    {
        UIManager.Instance?.ShowMonologue(conclusionMonologue);
    }

    public void OnHover()
    {
        if (currentStage < stages.Count)
            UIManager.Instance?.ShowInteractHint(stages[currentStage].actionPrompt);
    }

    public void OnHoverExit()
    {
        UIManager.Instance?.HideInteractHint();
    }
}

/// <summary>
/// Один этап осмотра тела
/// </summary>
[System.Serializable]
public class BodyInspectStage
{
    [Header("Действие")]
    public string actionPrompt = "[E] Осмотреть";  // Подсказка

    [TextArea(2, 6)]
    public string stageMonologue = "";  // Что говорит герой

    [Header("Предмет (опционально)")]
    public GameObject itemToReveal;     // Объект который появляется
    public string itemName = "";        // Добавить в инвентарь с этим именем
    public string itemDescription = ""; // И с этим описанием
}
